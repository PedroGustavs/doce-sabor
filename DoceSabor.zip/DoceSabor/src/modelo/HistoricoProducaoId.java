package modelo;

import java.io.Serializable;

public class HistoricoProducaoId implements Serializable{
    private int produto;
    private int codigo;
   

    public HistoricoProducaoId() {
    }

    public HistoricoProducaoId(int codigo, int produto) {
        this.codigo = codigo;
        this.produto = produto;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getProduto() {
        return produto;
    }

    public void setProduto(int produto) {
        this.produto = produto;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + this.codigo;
        hash = 97 * hash + this.produto;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final HistoricoProducaoId other = (HistoricoProducaoId) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        return this.produto == other.produto;
    }
}