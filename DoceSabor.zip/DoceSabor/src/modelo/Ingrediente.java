package modelo;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@NamedQueries({
    @NamedQuery(name = "Ingrediente.todos", 
                query = "SELECT i FROM Ingrediente i"),
    @NamedQuery(name = "Ingrediente.porNome",
                query = "SELECT i FROM Ingrediente i WHERE i.nome LIKE :nomequalquer")
})
@Table(name = "ingrediente")

public class Ingrediente implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo_ingrediente")
    private int codigo;
    
    @Column(name = "nome", nullable = false, length = 50)
    private String nome;
    
    @Column(name = "qntdd_min", nullable = false)
    private int qntddMinim;
    
    @Column(name = "qntdd_estoque", nullable = false)
    private int qntddEstoque;
    
    @Column(name = "valor_unitario", nullable = false)
    private double valor;
    
    @Column(name = "status", nullable = false, length = 15)
    private String status;
    
    @Column(name = "unidade_medida", nullable = false, length = 15)
    private String unidade;
    
    @OneToMany(cascade = CascadeType.ALL,
               orphanRemoval = true,
               mappedBy = "ingrediente") 
    private List<HistoricoConsumo> conjuntoConsumo = new ArrayList<>();

    public Ingrediente() {
    }

    public Ingrediente(int codigo, String nome, int qntddMinim, int qntddEstoque, double valor, String status, String unidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.qntddMinim = qntddMinim;
        this.qntddEstoque = qntddEstoque;
        this.valor = valor;
        this.status = status;
        this.unidade = unidade;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getUnidade() {
        return unidade;
    }

    public void setUnidade(String unidade) {
        this.unidade = unidade;
    }

    public int getQntddMinim() {
        return qntddMinim;
    }

    public void setQntddMinim(int qntddMinim) {
        this.qntddMinim = qntddMinim;
    }

    public int getQntddEstoque() {
        return qntddEstoque;
    }

    public void setQntddEstoque(int qntddEstoque) {
        this.qntddEstoque = qntddEstoque;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public void comprar(int quantidade){
        this.qntddEstoque += quantidade;
    }
    
    public void vender(int quantidade){
        this.qntddEstoque -= quantidade;
    }
    
    public void adicionarConsumo(HistoricoConsumo c)
    {
        c.setIngrediente(this);
        c.setCodigo(this.conjuntoConsumo.size()+1);     
        this.conjuntoConsumo.add(c);
    }
    
    public void removerConsumo(HistoricoConsumo hc){
        this.conjuntoConsumo.remove(hc);
    }
    public List<HistoricoConsumo> getConjuntoConsumo() {
        return conjuntoConsumo;
    }

    public void setConjuntoConsumo(List<HistoricoConsumo> conjuntoConsumo) {
        this.conjuntoConsumo = conjuntoConsumo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Ingrediente other = (Ingrediente) obj;
        return this.codigo == other.codigo;
    }
}