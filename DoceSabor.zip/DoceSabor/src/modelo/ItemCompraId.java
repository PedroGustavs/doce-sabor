package modelo;

import java.io.Serializable;

public class ItemCompraId implements Serializable{
    
    private int compra;
    private int codigo;

    public ItemCompraId(int compra, int codigo) {
        this.compra = compra;
        this.codigo = codigo;
    }

    public int getCompra() {
        return compra;
    }

    public void setCompra(int compra) {
        this.compra = compra;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + this.compra;
        hash = 31 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ItemCompraId other = (ItemCompraId) obj;
        if (this.compra != other.compra) {
            return false;
        }
        return this.codigo == other.codigo;
    } 
}