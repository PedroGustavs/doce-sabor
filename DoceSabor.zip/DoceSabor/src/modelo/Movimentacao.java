package modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import org.eclipse.persistence.annotations.ClassExtractor;

@Entity
@Table(name = "movimentacao")
@NamedQueries({
    @NamedQuery(name = "Movimentacao.todas", query="SELECT m FROM Movimentacao m"),
})
@IdClass(MovimentacaoId.class)

public class Movimentacao implements Serializable{
    
    @Id
    @ManyToOne
    @JoinColumn(name="codigo_caixa", referencedColumnName = "codigo_caixa")
    private Caixa caixa;
    
    @Id
    @Column(name = "codigo_movimentacao")
    private int codigo;
    
    @Column(name = "valor", nullable = false)
    private double valor;
    
    @Column(name = "motivo", nullable = false, length = 200)
    private String motivo;
    
    @Column(name = "tipo", nullable = false, length = 15)
    private String tipo;

    public Movimentacao() {
    }
 
    public Movimentacao(Caixa caixa, int codigo, double valor, String motivo, String tipo) {
        this.caixa = caixa;
        this.codigo = codigo;
        this.valor = valor;
        this.motivo = motivo;
        this.tipo = tipo;
    }

    public Caixa getCaixa() {
        return caixa;
    }

    public void setCaixa(Caixa caixa) {
        this.caixa = caixa;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Movimentacao other = (Movimentacao) obj;
        return this.codigo == other.codigo;
    }     
}