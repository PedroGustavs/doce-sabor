package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@NamedQueries({
    @NamedQuery(name = "Caixa.todas", query="SELECT c FROM Caixa c"),
    @NamedQuery(name = "Caixa.aberto", 
            query="SELECT c FROM Caixa c WHERE c.status IS NULL")
})

@Table(name = "caixa")

public class Caixa implements Serializable{
    
    @ManyToOne
    @JoinColumn(name="codigo_funcionario", referencedColumnName = "codigo_funcionario", nullable = false)
    private Funcionario funcionario;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo_caixa")
    private int codigo;
    
    @Column(name = "data_abertura")
    @Temporal(TemporalType.DATE)
    private Date dataAbertura;
    
    @Column(name = "horario_abertura")
    @Temporal(TemporalType.TIME)
    private Date horarioAbertura;
    
    @Column(name = "horario_fechamento")
    @Temporal(TemporalType.TIME)
    private Date horarioFechamento;
    
    @Column(name = "entradas", nullable = true)
    private double entradas;
    
    @Column(name = "saidas", nullable = true)
    private double saidas;
    
    @Column(name = "saldo", nullable = true)
    private double saldo;
    
    @Column(name = "status", nullable = false, length = 15)
    private String status;
    
    @OneToMany(cascade = CascadeType.ALL,
               orphanRemoval = true,
               mappedBy = "caixa")
    private List<Movimentacao> conjuntoMovimentacao = new ArrayList<>();

    public Caixa() {
    }

    public Caixa(Funcionario funcionario, int codigo, Date dataAbertura, Date horarioAbertura, Date horarioFechamento, double entradas, double saidas, double saldo, String status) {
        this.funcionario = funcionario;
        this.codigo = codigo;
        this.dataAbertura = dataAbertura;
        this.horarioAbertura = horarioAbertura;
        this.horarioFechamento = horarioFechamento;
        this.entradas = entradas;
        this.saidas = saidas;
        this.saldo = saldo;
        this.status = status;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }
    
    public double retorneSaidas(){
        double saida = 0;
        for(Movimentacao m : conjuntoMovimentacao){
            if(!m.getMotivo().equals("Fechamento de Caixa")){
                saida += m.getValor();
            }
        }
        
        return saida;
    }
    
     public double retorneEntradas(){
        double entrada = 0;
        for(Movimentacao m : conjuntoMovimentacao){
            entrada += m.getValor(); 
        }
        
        return entrada;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Date getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(Date dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public Date getHorarioAbertura() {
        return horarioAbertura;
    }

    public void setHorarioAbertura(Date horarioAbertura) {
        this.horarioAbertura = horarioAbertura;
    }

    public Date getHorarioFechamento() {
        return horarioFechamento;
    }

    public void setHorarioFechamento(Date horarioFechamento) {
        this.horarioFechamento = horarioFechamento;
    }
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public double getEntradas() {
        return entradas;
    }

    public void setEntradas(double entradas) {
        this.entradas = entradas;
    }

    public double getSaidas() {
        return saidas;
    }

    public void setSaidas(double saidas) {
        this.saidas = saidas;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<Movimentacao> getConjuntoMovimentacao() {
        return conjuntoMovimentacao;
    }
    
    public void adicionarMovimentacao(Movimentacao m)
    {
        m.setCaixa(this);
        m.setCodigo(this.conjuntoMovimentacao.size()+1);     
        this.conjuntoMovimentacao.add(m);
    }

    public void setConjuntoMovimentacao(List<Movimentacao> conjuntoMovimentacao) {
        this.conjuntoMovimentacao = conjuntoMovimentacao;
    }
    
    public void removerMovimentacao(Movimentacao m){
        this.conjuntoMovimentacao.remove(m);
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 23 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Caixa other = (Caixa) obj;
        return this.codigo == other.codigo;
    }
}