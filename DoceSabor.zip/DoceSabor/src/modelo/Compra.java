package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@NamedQueries({
    @NamedQuery(name = "Compra.todas", 
                query = "SELECT c FROM Compra c"),
})
@Table(name = "compra")

public class Compra implements Serializable {
    
    @ManyToOne
    @JoinColumn(name="codigo_fornecedor", referencedColumnName = "codigo_fornecedor", nullable = false)
    private Fornecedor fornecedor;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo_compra")
    private int codigo;
    
    @Column(name = "dataCompra", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dataCompra;
    
    @Column(name = "dataPagamento", nullable = true)
    @Temporal(TemporalType.DATE)
    private Date dataPagamento;
    
    @Column(name = "formaPagamento", nullable = false, length = 30)
    private String formaPagamento;
    
    @Column(name = "valorFinal", nullable = false)
    private double valorFinal;
    
    @OneToMany(cascade = CascadeType.ALL,
               orphanRemoval = true,
               mappedBy = "compra")
    private List<ItemCompra> conjuntoItemCompra = new ArrayList<>();

    public Compra() {
    }

    public Compra(Fornecedor fornecedor, int codigo, Date dataCompra, Date dataPagamento, String formaPagamento, double valorFinal) {
        this.fornecedor = fornecedor;
        this.codigo = codigo;
        this.dataCompra = dataCompra;
        this.dataPagamento = dataPagamento;
        this.formaPagamento = formaPagamento;
        this.valorFinal = valorFinal;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getDataCompra() {
        return dataCompra;
    }

    public void setDataCompra(Date dataCompra) {
        this.dataCompra = dataCompra;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(Date dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public double getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(double valorFinal) {
        this.valorFinal = valorFinal;
    }
    
     public void adicionarItemCompra(ItemCompra c)
    {
        c.setCompra(this);
        c.setCodigo(this.conjuntoItemCompra.size()+1);     
        this.conjuntoItemCompra.add(c);
    }
    
    public void removerItemCompra(ItemCompra c){
        this.conjuntoItemCompra.remove(c);
    }

    public List<ItemCompra> getConjuntoItemCompra() {
        return conjuntoItemCompra;
    }

    public void setConjuntoItemCompra(List<ItemCompra> conjuntoItemCompra) {
        this.conjuntoItemCompra = conjuntoItemCompra;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 43 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Compra other = (Compra) obj;
        return this.codigo == other.codigo;
    }
}