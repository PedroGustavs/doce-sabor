package modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({
    @NamedQuery(name = "Fornecedor.todos", 
                query = "SELECT f FROM Fornecedor f"),
    @NamedQuery(name = "Fornecedor.porNome",
                query = "SELECT f FROM Fornecedor f WHERE f.nome LIKE :nomequalquer")
})
@Table(name = "fornecedor")

public class Fornecedor implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo_fornecedor")
    private int codigo;
    
    @Column(name = "nome", nullable = false, length = 50)
    private String nome;
    
    @Column(name = "nomeContato", nullable = false, length = 50)
    private String nomeContato;
    
    @Column(name = "telefone", nullable = false, length = 15)
    private String telefone;
    
    @Column(name = "email", nullable = false, length = 50)
    private String email;
    
    @Column(name = "cnpj", nullable = false, length = 18)
    private String cnpj;
    
    @Column(name = "rua", nullable = false, length = 50)
    private String rua;
    
    @Column(name = "numero", nullable = false)
    private int numero;
    
    @Column(name = "bairro", nullable = false, length = 50)
    private String bairro;
    
    @Column(name = "cidade", nullable = false, length = 50)
    private String cidade;
    
    @Column(name = "estado", nullable = false, length = 2)
    private String estado;
    
    @Column(name = "cep", nullable = false, length = 9)
    private String cep;

    public Fornecedor() {
    }

    public Fornecedor(int codigo, String nome, String nomeContato, String telefone, String email, String cnpj, String rua, int numero, String bairro, String cidade, String estado, String cep) {
        this.codigo = codigo;
        this.nome = nome;
        this.nomeContato = nomeContato;
        this.telefone = telefone;
        this.email = email;
        this.cnpj = cnpj;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.cep = cep;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNomeContato() {
        return nomeContato;
    }

    public void setNomeContato(String nomeContato) {
        this.nomeContato = nomeContato;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Fornecedor other = (Fornecedor) obj;
        return this.codigo == other.codigo;
    } 
}