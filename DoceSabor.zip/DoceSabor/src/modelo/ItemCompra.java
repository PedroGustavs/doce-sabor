package modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "item_compra")
@IdClass (ItemCompraId.class)

public class ItemCompra implements Serializable {

    @Id
    @ManyToOne
    @JoinColumn(name="codigo_compra", referencedColumnName = "codigo_compra", nullable = false)
    private Compra compra;
    
    @Id
    @Column(name = "codigo_item", nullable = false)
    private int codigo;
    
    @ManyToOne
    @JoinColumn(name="codigo_ingrediente", referencedColumnName = "codigo_ingrediente", nullable = false)
    private Ingrediente ingrediente;
    
    @Column(name = "qntdd", nullable = false)
    private int qntdd;
    
    @Column(name = "valor", nullable = false)
    private double valor;

    public Ingrediente getIngrediente() {
        return ingrediente;
    }

    public void setIngrediente(Ingrediente ingrediente) {
        this.ingrediente = ingrediente;
    }

    public Compra getCompra() {
        return compra;
    }

    public void setCompra(Compra compra) {
        this.compra = compra;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getQntdd() {
        return qntdd;
    }

    public void setQntdd(int qntdd) {
        this.qntdd = qntdd;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ItemCompra other = (ItemCompra) obj;
        return this.codigo == other.codigo;
    }
}