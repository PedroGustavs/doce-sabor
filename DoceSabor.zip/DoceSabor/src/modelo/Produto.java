package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity

@NamedQueries({
    @NamedQuery(name = "Produto.todos", 
                query = "SELECT p FROM Produto p"),
    @NamedQuery(name = "Produto.porNome",
                query = "SELECT p FROM Produto p WHERE p.nome LIKE :nomequalquer")
})

@Table(name = "produto")

public class Produto implements Serializable{
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "codigo_produto")
    private int codigo;
    
    @Column(name = "nome", nullable = false, length = 50)
    private String nome;
    
    @Column(name = "qntdd_estoque", nullable = false)
    private int estoque;
    
    @Column(name = "qntdd_min", nullable = false)
    private int qntddMin;
    
    @Column(name = "valor_unitario", nullable = false)
    private double valor;
    
    @Column(name = "status", nullable = false, length = 15)
    private String status;
    
    @OneToMany(cascade = CascadeType.ALL,
               orphanRemoval = true,
               mappedBy = "produto")
    private List<HistoricoProducao> conjuntoProducao = new ArrayList<>();
 
    public Produto() {      
    }

    public Produto(int codigo, String nome, int estoque, int qntddMin, double valor, String status) {
        this.codigo = codigo;
        this.nome = nome;
        this.estoque = estoque;
        this.qntddMin = qntddMin;
        this.valor = valor;
        this.status = status;
    }
    
    public void adicionarProducao(HistoricoProducao p)
    {
        p.setProduto(this);
        p.setCodigo(this.conjuntoProducao.size()+1);     
        this.conjuntoProducao.add(p);
    }
    
    public List<HistoricoProducao> getProducoes() {
        return this.conjuntoProducao;
    }

    public void setProducao(List<HistoricoProducao> itens) {
        this.conjuntoProducao = itens;
    }
    
    public void removerProducao(HistoricoProducao hp){
        this.conjuntoProducao.remove(hp);
    }
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public int getQntddMin() {
        return qntddMin;
    }

    public void setQntddMin(int qntddMin) {
        this.qntddMin = qntddMin;
    }
    
    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public void vender(int quantidade)
    {
        this.estoque -= quantidade;
    }
    
    public void comprar(int quantidade){
        this.estoque += quantidade;
    }

    @Override
    public String toString() {
        return "Produto{" + "codigo=" + codigo + ", nome=" + nome + ", estoque=" + estoque + ", qntddMin=" + qntddMin + ", valor=" + valor + ", status=" + status + ", conjuntoProducao=" + conjuntoProducao + '}';
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 61 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Produto other = (Produto) obj;
        return this.codigo == other.codigo;
    }
}