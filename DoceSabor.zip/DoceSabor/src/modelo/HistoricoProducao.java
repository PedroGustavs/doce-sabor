package modelo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "historico_producao")

@IdClass(HistoricoProducaoId.class)
public class HistoricoProducao implements Serializable{
    
    @Id
    @ManyToOne
    @JoinColumn(name="codigo_produto", referencedColumnName = "codigo_produto")
    private Produto produto;
       
    @Id
    @Column(name = "codigo_producao", nullable = false)
    private int codigo;
  
    @Column(name = "qntdd", nullable = false)
    private int qntdd;
    
    @Column(name = "data", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date data;

    public HistoricoProducao() {
    }

    public HistoricoProducao(int codigo, Produto produto, int qntdd, Date data) {
        this.codigo = codigo;
        this.produto = produto;
        this.qntdd = qntdd;
        this.data = data;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto cod_produto) {
        this.produto = cod_produto;
    }

    public int getQntdd() {
        return qntdd;
    }

    public void setQntdd(int qntdd) {
        this.qntdd = qntdd;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final HistoricoProducao other = (HistoricoProducao) obj;
        return this.codigo == other.codigo;
    }
}