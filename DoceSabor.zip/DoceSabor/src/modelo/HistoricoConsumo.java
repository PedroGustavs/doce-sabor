package modelo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "historico_consumo")
@IdClass(HistoricoConsumoId.class)

public class HistoricoConsumo implements Serializable{
    
    @Id
    @ManyToOne
    @JoinColumn(name="codigo_ingrediente", referencedColumnName = "codigo_ingrediente")
    private Ingrediente ingrediente;
       
    @Id
    @Column(name = "codigo_consumo", nullable = false)
    private int codigo;
    
    @Column(name = "qntdd", nullable = false)
    private int qntdd;
    
    @Column(name = "data", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date data;

    public HistoricoConsumo() {
    }

    public HistoricoConsumo(Ingrediente ingrediente, int codigo, int qntdd, Date data) {
        this.ingrediente = ingrediente;
        this.codigo = codigo;
        this.qntdd = qntdd;
        this.data = data;
    }

    public Ingrediente getIngrediente() {
        return ingrediente;
    }

    public void setIngrediente(Ingrediente ingrediente) {
        this.ingrediente = ingrediente;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getQntdd() {
        return qntdd;
    }

    public void setQntdd(int qntdd) {
        this.qntdd = qntdd;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final HistoricoConsumo other = (HistoricoConsumo) obj;
        return this.codigo == other.codigo;
    }
}