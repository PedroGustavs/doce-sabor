package modelo;

import java.io.Serializable;

public class MovimentacaoId implements Serializable{
    
    private int caixa;
    private int codigo;

    public MovimentacaoId() {
    }

    public MovimentacaoId(int caixa, int codigo) {
        this.caixa = caixa;
        this.codigo = codigo;
    }

    public int getCaixa() {
        return caixa;
    }

    public void setCaixa(int caixa) {
        this.caixa = caixa;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + this.caixa;
        hash = 37 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MovimentacaoId other = (MovimentacaoId) obj;
        if (this.caixa != other.caixa) {
            return false;
        }
        return this.codigo == other.codigo;
    }  
}