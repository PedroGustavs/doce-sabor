package modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "item_venda")
@IdClass (ItemVendaId.class)

public class ItemVenda implements Serializable{
 
    @Id
    @ManyToOne
    @JoinColumn(name="codigo_venda", referencedColumnName = "codigo_venda", nullable = false)
    private Venda venda;
    
    @Id
    @Column(name = "codigo_item", nullable = false)
    private int codigo;
    
    @ManyToOne
    @JoinColumn(name="codigo_produto", referencedColumnName = "codigo_produto", nullable = false)
    private Produto produto;
   
    @Column(name = "qntdd", nullable = false)
    private int qntdd;
    
    @Column(name = "valor", nullable = false)
    private double valor;

    public ItemVenda() {
    }

    public ItemVenda(Produto produto, Venda venda, int codigo, int qntdd, double valor) {
        this.produto = produto;
        this.venda = venda;
        this.codigo = codigo;
        this.qntdd = qntdd;
        this.valor = valor;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getQntdd() {
        return qntdd;
    }

    public void setQntdd(int qntdd) {
        this.qntdd = qntdd;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ItemVenda other = (ItemVenda) obj;
        return this.codigo == other.codigo;
    }
}