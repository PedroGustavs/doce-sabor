package modelo;

import java.io.Serializable;

public class ItemVendaId implements Serializable{
    
    private int venda;
    private int codigo;

    public ItemVendaId() {
    }

    public ItemVendaId(int venda, int codigo) {
        this.venda = venda;
        this.codigo = codigo;
    }

    public int getVenda() {
        return venda;
    }

    public void setVenda(int venda) {
        this.venda = venda;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public int hashCode() {
        int hash = 3;
          hash = 53 * hash + this.venda;
        hash = 53 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ItemVendaId other = (ItemVendaId) obj;
        if (this.venda != other.venda) {
            return false;
        }
        return this.codigo == other.codigo;
    }  
}