package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import java.util.Date;

@Entity
@NamedQueries({
    @NamedQuery(name = "Venda.todos", 
                query = "SELECT v FROM Venda v"),
})
@Table(name = "venda")

public class Venda implements Serializable{
     
    @ManyToOne
    @JoinColumn(name="codigo_consumidor", referencedColumnName = "codigo_consumidor", nullable = true)
    private Consumidor consumidor;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo_venda")
    private int codigo;
    
    @Column(name = "dataVenda", nullable = true)
    @Temporal(TemporalType.DATE)
    private Date dataVenda;
    
    @Column(name = "dataOrcamento", nullable = true)
    @Temporal(TemporalType.DATE)
    private Date dataOrcamento;
    
    @Column(name = "dataConclusao", nullable = true)
    @Temporal(TemporalType.DATE)
    private Date dataConclusao;
    
    @Column(name = "dataPagamento", nullable = true)
    @Temporal(TemporalType.DATE)
    private Date dataPagamento;
    
    @Column(name = "dataEntrega", nullable = true)
    @Temporal(TemporalType.DATE)
    private Date dataEntrega;
    
    @Column(name = "dataAprovacao", nullable = true)
    @Temporal(TemporalType.DATE)
    private Date dataAprovacao;
    
    @Column(name = "dataValidade", nullable = true)
    @Temporal(TemporalType.DATE)
    private Date dataValidade;
    
    @Column(name = "tipoVenda", nullable = false, length = 45)
    private String tipoVenda;
    
    @Column(name = "formaPagamento", nullable = true, length = 30)
    private String formaPagamento;
    
    @Column(name = "valorFinal", nullable = false)
    private double valorFinal;
    
    @OneToMany(cascade = CascadeType.ALL,
               orphanRemoval = true,
               mappedBy = "venda")
    private List<ItemVenda> conjuntoItemVenda = new ArrayList<>();
    
    public Venda() {
    }

    public Venda(Consumidor consumidor, int codigo, Date dataVenda, Date dataOrcamento, Date dataConclusao, Date dataPagamento, Date dataEntrega, Date dataAprovacao, Date dataValidade, String tipoVenda, String formaPagamento, double valorFinal) {
        this.consumidor = consumidor;
        this.codigo = codigo;
        this.dataVenda = dataVenda;
        this.dataOrcamento = dataOrcamento;
        this.dataConclusao = dataConclusao;
        this.dataPagamento = dataPagamento;
        this.dataEntrega = dataEntrega;
        this.dataAprovacao = dataAprovacao;
        this.dataValidade = dataValidade;
        this.tipoVenda = tipoVenda;
        this.formaPagamento = formaPagamento;
        this.valorFinal = valorFinal;
    }

    public Date getDataOrcamento() {
        return dataOrcamento;
    }

    public void setDataOrcamento(Date dataOrcamento) {
        this.dataOrcamento = dataOrcamento;
    }

    public void adicionarItemVenda(ItemVenda i)
    {
        i.setVenda(this);
        i.setCodigo(this.conjuntoItemVenda.size()+1);     
        this.conjuntoItemVenda.add(i);
    }
    
    public void setItemVenda(List<ItemVenda> itens) {
        this.conjuntoItemVenda = itens;
    }
    
    public void removerProducao(ItemVenda i){
        this.conjuntoItemVenda.remove(i);
    }

    public Consumidor getConsumidor() {
        return consumidor;
    }

    public void setConsumidor(Consumidor consumidor) {
        this.consumidor = consumidor;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Date dataVenda) {
        this.dataVenda = dataVenda;
    }

    public Date getDataAprovacao() {
        return dataAprovacao;
    }

    public void setDataAprovacao(Date dataAprovacao) {
        this.dataAprovacao = dataAprovacao;
    }

    public Date getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(Date dataValidade) {
        this.dataValidade = dataValidade;
    }

    public Date getDataConclusao() {
        return dataConclusao;
    }

    public void setDataConclusao(Date dataConclusao) {
        this.dataConclusao = dataConclusao;
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(Date dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public String getTipoVenda() {
        return tipoVenda;
    }

    public void setTipoVenda(String tipoVenda) {
        this.tipoVenda = tipoVenda;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(Date dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public double getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(double valorFinal) {
        this.valorFinal = valorFinal;
    }

    public List<ItemVenda> getConjuntoItemVenda() {
        return conjuntoItemVenda;
    }

    public void setConjuntoItemVenda(List<ItemVenda> conjuntoItemVenda) {
        this.conjuntoItemVenda = conjuntoItemVenda;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Venda other = (Venda) obj;
        return this.codigo == other.codigo;
    }
}