package modelo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@NamedQueries({
    @NamedQuery(name = "Funcionario.todos", 
                query = "SELECT f FROM Funcionario f"),
    @NamedQuery(name = "Funcionario.porNome", 
                query = "SELECT f FROM Funcionario f WHERE f.nome LIKE :nome"),
   @NamedQuery(name = "Funcionario.login", 
                query = "SELECT f FROM Funcionario f WHERE f.cpf = :cpf AND f.senha = :senha")  
})
@Table(name = "funcionario")

public class Funcionario implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo_funcionario")
    private int codigo;
    
    @Column(name = "nome", nullable = false, length = 50)
    private String nome;
    
    @Column(name = "salario", nullable = false)
    private double salario;
    
    @Column(name = "senha", nullable = false, length = 15)
    private String senha;
    
    @Column(name = "data_admissao", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date data_admissao; 
    
    @Column(name = "dataDemissao", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date data_demissao; 
    
    @Column(name = "cargo", nullable = false, length = 15)
    private String cargo;
    
    @Column(name = "telefone", nullable = false, length = 15)
    private String telefone;
    
    @Column(name = "email", nullable = false, length = 50)
    private String email;
    
    @Column(name = "cpf", nullable = false, length = 14)
    private String cpf;
    
    @Column(name = "rua", nullable = false, length = 50)
    private String rua;
    
    @Column(name = "numero", nullable = false)
    private int numero;
    
    @Column(name = "bairro", nullable = false, length = 50)
    private String bairro;
    
    @Column(name = "cidade", nullable = false, length = 50)
    private String cidade;
    
    @Column(name = "estado", nullable = false, length = 2)
    private String estado;
    
    @Column(name = "cep", nullable = false, length = 9)
    private String cep;

    public Funcionario() {
    }

    public Funcionario(int codigo, String nome, double salario, String senha, Date data_admissao, Date data_demissao, String cargo, String telefone, String email, String cpf, String rua, int numero, String bairro, String cidade, String estado, String cep) {
        this.codigo = codigo;
        this.nome = nome;
        this.salario = salario;
        this.senha = senha;
        this.data_admissao = data_admissao;
        this.data_demissao = data_demissao;
        this.cargo = cargo;
        this.telefone = telefone;
        this.email = email;
        this.cpf = cpf;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.cep = cep;
    }

    public Date getData_demissao() {
        return data_demissao;
    }

    public void setData_demissao(Date data_demissao) {
        this.data_demissao = data_demissao;
    }
  
 
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Date getData_admissao() {
        return data_admissao;
    }

    public void setData_admissao(Date data_admissao) {
        this.data_admissao = data_admissao;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Funcionario other = (Funcionario) obj;
        return this.codigo == other.codigo;
    }
}