package modelo;

public class HistoricoConsumoId {
    private int ingrediente;
    private int codigo;

    public HistoricoConsumoId() {
    }

    public HistoricoConsumoId(int ingrediente, int codigo) {
        this.ingrediente = ingrediente;
        this.codigo = codigo;
    }

    public int getIngrediente() {
        return ingrediente;
    }

    public void setIngrediente(int ingrediente) {
        this.ingrediente = ingrediente;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 19 * hash + this.ingrediente;
        hash = 19 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final HistoricoConsumoId other = (HistoricoConsumoId) obj;
        if (this.ingrediente != other.ingrediente) {
            return false;
        }
        return this.codigo == other.codigo;
    }
}