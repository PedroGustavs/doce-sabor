
package componentes;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TextFieldSearch extends JTextField {
    
    private Color backgroundColor = new Color(189, 195, 199 );
    private Color animationColor = new Color(3, 175, 255);
    private Icon iconSearch;

    public TextFieldSearch() {
        super.setBackground(new Color(255, 255, 255, 0)); //  Remove background
        setOpaque(false);
        setText("Pesquise aqui");
        setBorder(new EmptyBorder(10, 10, 10, 50)); //  Set Right border 50
        setFont(new java.awt.Font("sansserif", 0, 14));
        setSelectionColor(new Color(175, 107, 255));
        iconSearch = new ImageIcon(getClass().getResource("/imagem/icons8-pesquisar-65.png"));
    }

    @Override
    protected void paintComponent(Graphics grphcs) {
        int width = getWidth();
        int height = getHeight();
        Graphics2D g2 = (Graphics2D) grphcs;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);    //  For smooth line
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR); //  For smooth image
        g2.setColor(backgroundColor);
        g2.fillRoundRect(0, 0, width, height, height, height);
        super.paintComponent(grphcs);
        int marginButton = 5;
        int buttonSize = height - marginButton * 2;
         GradientPaint gradiente = new GradientPaint(0, 0, Color.decode("#370d5e"), 0, getHeight(), Color.decode("#c187ff"));
       
        g2.setPaint(gradiente);
        g2.fillOval(width - height + 3, marginButton, buttonSize, buttonSize);
        
         int marginImage = 5;
        int imageSize = buttonSize - marginImage * 2;
        Image image = ((ImageIcon) iconSearch).getImage();;
        g2.drawImage(image, width - height + marginImage + 3, marginButton + marginImage, imageSize, imageSize, null);
        g2.dispose();

    }   
    
    
    
}
