package componentes;

import controle.ControleFuncionario;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import visao.TelaConfiguracoes;
import visao.TelaManutencaoCompra;
import visao.TelaManutencaoConsumidor;
import visao.TelaManutencaoIngrediente;
import visao.TelaManutencaoOrcamento;
import visao.TelaManutencaoProdutos;
import visao.TelaManutencaoVenda;
import visao.TelaVisualizacaoCaixas;

public class Menu extends javax.swing.JPanel {

    public Menu() {
        initComponents();
        setOpaque(false);
        
        if(ControleFuncionario.getFuncionarioLogado() != null){
        
            String tipo = ControleFuncionario.getFuncionarioLogado().getCargo();
            if(tipo.equals("Cozinheira")){
                btnVenda.setText("Encomendas");
                btnCompra1.setText("Produto");
                btnOrcamento.setText("Ingrediente");
                btnCaixa.setVisible(false);
            }
            else if(tipo.equals("Atendente")){
                btnCompra1.setText("Consumidor");
            }
        }
        
    }

    @Override
    protected void paintChildren(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        GradientPaint gradiente = new GradientPaint(0, 0, Color.decode("#370d5e"), 0, getHeight(), Color.decode("#c187ff"));
        g2.setPaint(gradiente);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
        
       g2.fillRect(getWidth() - 20, 0, getWidth(), getHeight());
        
        super.paintChildren(g);
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnVenda = new javax.swing.JButton();
        btnCompra1 = new javax.swing.JButton();
        btnOrcamento = new javax.swing.JButton();
        btnCaixa = new javax.swing.JButton();
        btnConfiguracoes = new javax.swing.JButton();

        jPanel1.setOpaque(false);

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-confeitaria-48.png"))); // NOI18N
        jLabel1.setText("Doce Sabor");

        btnVenda.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        btnVenda.setForeground(new java.awt.Color(255, 255, 255));
        btnVenda.setText("Vendas");
        btnVenda.setBorderPainted(false);
        btnVenda.setContentAreaFilled(false);
        btnVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVendaActionPerformed(evt);
            }
        });

        btnCompra1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        btnCompra1.setForeground(new java.awt.Color(255, 255, 255));
        btnCompra1.setText("Compras");
        btnCompra1.setBorderPainted(false);
        btnCompra1.setContentAreaFilled(false);
        btnCompra1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCompra1ActionPerformed(evt);
            }
        });

        btnOrcamento.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        btnOrcamento.setForeground(new java.awt.Color(255, 255, 255));
        btnOrcamento.setText("Orçamentos");
        btnOrcamento.setBorderPainted(false);
        btnOrcamento.setContentAreaFilled(false);
        btnOrcamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrcamentoActionPerformed(evt);
            }
        });

        btnCaixa.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        btnCaixa.setForeground(new java.awt.Color(255, 255, 255));
        btnCaixa.setText("Caixas");
        btnCaixa.setBorderPainted(false);
        btnCaixa.setContentAreaFilled(false);
        btnCaixa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCaixaActionPerformed(evt);
            }
        });

        btnConfiguracoes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-configurações-70.png"))); // NOI18N
        btnConfiguracoes.setBorderPainted(false);
        btnConfiguracoes.setContentAreaFilled(false);
        btnConfiguracoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfiguracoesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnCompra1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnOrcamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnCaixa, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btnVenda, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(btnConfiguracoes)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(48, 48, 48)
                .addComponent(btnVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(btnCompra1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(btnOrcamento, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(btnCaixa, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 113, Short.MAX_VALUE)
                .addComponent(btnConfiguracoes)
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnOrcamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrcamentoActionPerformed
        if(ControleFuncionario.getFuncionarioLogado() != null){
        
            String tipo = ControleFuncionario.getFuncionarioLogado().getCargo();
            if(tipo.equals("Cozinheira")){
                TelaManutencaoProdutos tela = new TelaManutencaoProdutos(null, true);
                tela.setVisible(true);
            }
            else{
                TelaManutencaoOrcamento tela = new TelaManutencaoOrcamento(null, true);
                tela.setVisible(true);
            }
        } 
    }//GEN-LAST:event_btnOrcamentoActionPerformed

    private void btnVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVendaActionPerformed
       TelaManutencaoVenda tela = new TelaManutencaoVenda(null, true);
       tela.setVisible(true);
    }//GEN-LAST:event_btnVendaActionPerformed

    private void btnCaixaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCaixaActionPerformed
       TelaVisualizacaoCaixas tela = new TelaVisualizacaoCaixas(null, true);
       tela.setVisible(true);
    }//GEN-LAST:event_btnCaixaActionPerformed

    private void btnCompra1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCompra1ActionPerformed
        
        if(ControleFuncionario.getFuncionarioLogado() != null){
        
            String tipo = ControleFuncionario.getFuncionarioLogado().getCargo();
            if(tipo.equals("Cozinheira")){
                TelaManutencaoIngrediente tela = new TelaManutencaoIngrediente(null, true);
                tela.setVisible(true);
            }
            else if(tipo.equals("Atendente")){
                TelaManutencaoConsumidor tela = new TelaManutencaoConsumidor(null, true);
                tela.setVisible(true);
            }
            else{
                TelaManutencaoCompra tela = new TelaManutencaoCompra(null, true);
                tela.setVisible(true);
            }
        } 
    }//GEN-LAST:event_btnCompra1ActionPerformed

    private void btnConfiguracoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfiguracoesActionPerformed
        TelaConfiguracoes tela = new TelaConfiguracoes();
        tela.setVisible(true);
    }//GEN-LAST:event_btnConfiguracoesActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCaixa;
    private javax.swing.JButton btnCompra1;
    private javax.swing.JButton btnConfiguracoes;
    private javax.swing.JButton btnOrcamento;
    private javax.swing.JButton btnVenda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
