package controle;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import modelo.Compra;
import modelo.Ingrediente;
import modelo.ItemCompra;


public class ControleCompra {
    
    public void adicionar(Compra c){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.persist(c);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void darBaixa(Compra c){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin(); 
        Ingrediente ingrediente = null;
        for(ItemCompra ic : c.getConjuntoItemCompra())
        {
            ingrediente = ic.getIngrediente();
            ingrediente.comprar(ic.getQntdd());
            ingrediente.setStatus("Disponível");
            gerente.merge(ingrediente);       
        }
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void alterar(Compra c){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.merge(c);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void remover(Compra c){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        Compra compra = gerente.find(Compra.class, c.getCodigo());
        gerente.remove(compra);
        
        Ingrediente ingrediente = null;
        for(ItemCompra ic : c.getConjuntoItemCompra())
        {
            ingrediente = ic.getIngrediente();
            ingrediente.vender(ic.getQntdd());
            
            if(ingrediente.getQntddEstoque() == 0){
                ingrediente.setStatus("Indisponível");
            }
            gerente.merge(ingrediente);       
        }
        
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public java.util.List<Compra> getAll()
    {
       EntityManager gerente = GerenciadorConexao.getGerente();
       TypedQuery<Compra> consulta = gerente.createNamedQuery("Compra.todas", Compra.class);
       return consulta.getResultList();   
   }
    
}
