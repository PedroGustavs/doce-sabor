package controle;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class GerenciadorConexao {
    private static EntityManagerFactory emf;
    
    public static EntityManagerFactory getFabrica()
    {
        // verifica se a fábrica não existe
        if(emf == null)
        {
            // cria uma EntityManagerFactory e associa a emf
            emf = Persistence.createEntityManagerFactory("DoceSaborPU");
        }
        return emf;
    }
    
    public static EntityManager getGerente()
    {
        // retorna uma entitmanager a partir da fábrica existente
        return getFabrica().createEntityManager();
    }
    
}


