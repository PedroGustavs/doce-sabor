package controle;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import modelo.Fornecedor;


public class ControleFornecedor {
    
    public void adicionar(Fornecedor f){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.persist(f);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void alterar(Fornecedor f){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.merge(f);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void remover(Fornecedor f){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        Fornecedor fornecedor = gerente.find(Fornecedor.class, f.getCodigo());
        gerente.remove(fornecedor);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public java.util.List<Fornecedor> getAll()
    {
       EntityManager gerente = GerenciadorConexao.getGerente();
       TypedQuery<Fornecedor> consulta = gerente.createNamedQuery("Fornecedor.todos", Fornecedor.class);
       return consulta.getResultList();   
   }
}
