package controle;

import java.awt.List;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import modelo.Produto;

public class ControleProduto {
 
    public void adicionar(Produto p){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.persist(p);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void alterar(Produto p){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.merge(p);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void remover(Produto p){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        Produto produto = gerente.find(Produto.class, p.getCodigo());
        gerente.remove(produto);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public java.util.List<Produto> getAll()
    {
       EntityManager gerente = GerenciadorConexao.getGerente();
       TypedQuery<Produto> consulta = gerente.createNamedQuery("Produto.todos", Produto.class);
       return consulta.getResultList();   
   }
   
   public java.util.List<Produto> pesquisarPorNome(String nome)
   {
       EntityManager gerente = GerenciadorConexao.getGerente();
       TypedQuery<Produto> consulta = gerente.createNamedQuery("Produto.porNome", Produto.class);
       consulta.setParameter("nomequalquer", "%"+nome+"%");
       return consulta.getResultList();
   }
}
