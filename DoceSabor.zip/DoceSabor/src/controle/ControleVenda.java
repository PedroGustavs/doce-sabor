package controle;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import modelo.Caixa;
import modelo.ItemVenda;
import modelo.Produto;
import modelo.Venda;

public class ControleVenda {
    
    public void adicionar(Venda v){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.persist(v);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void darBaixa(Venda v){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        Produto p = null;
        for(ItemVenda iv : v.getConjuntoItemVenda())
        {
            p = iv.getProduto();
            p.vender(iv.getQntdd());
            gerente.merge(p);       
        }
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void alterar(Venda v){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.merge(v);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void remover(Venda v){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        Venda venda = gerente.find(Venda.class, v.getCodigo());
        gerente.remove(venda);
        
        if(!v.getTipoVenda().equals("Orçamento")){
            
            Produto p = null;
            for(ItemVenda iv : v.getConjuntoItemVenda())
            {
                p = iv.getProduto();
                p.comprar(iv.getQntdd());
                gerente.merge(p);       
            }
        }
        
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public java.util.List<Venda> getAll()
    {
       EntityManager gerente = GerenciadorConexao.getGerente();
       TypedQuery<Venda> consulta = gerente.createNamedQuery("Venda.todos", Venda.class);
       return consulta.getResultList();   
   }
 
}
