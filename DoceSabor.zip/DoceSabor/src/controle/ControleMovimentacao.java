package controle;

import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import modelo.Caixa;
import modelo.Movimentacao;

public class ControleMovimentacao {
    
    public void adicionar(Movimentacao movimentacao)
    {
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.persist(movimentacao);
        gerente.getTransaction().commit();
        gerente.close();
    }

    public void remover(Movimentacao m)
    {
        EntityManager gerente = GerenciadorConexao.getGerente();
        Movimentacao movimentacao = gerente.find(Movimentacao.class, 
                                       m.getCodigo());
        gerente.getTransaction().begin();
        gerente.remove(movimentacao);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void alterar(Movimentacao m)
    {
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.merge(m);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void quitar(Movimentacao m)
    {
        m.setCaixa(ControleCaixa.getCaixaAberto());
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.merge(m);
        gerente.getTransaction().commit();
        gerente.close();
    }    
    
    public List<Movimentacao> getTodas()
    {
        EntityManager gerente = GerenciadorConexao.getGerente();
        TypedQuery<Movimentacao> consulta = 
                    gerente.createNamedQuery("Movimentacao.todas", Movimentacao.class);
        return consulta.getResultList();
        
    }
    
}