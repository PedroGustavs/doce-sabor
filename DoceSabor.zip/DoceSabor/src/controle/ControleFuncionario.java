package controle;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import modelo.Funcionario;

public class ControleFuncionario {
    
    private static Funcionario funcionarioLogado = null;
    private static boolean logado = false;
    
    
    public Boolean verificaLogado(){
        return logado;
    }
    
    public void adicionar(Funcionario f){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.persist(f);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void alterar(Funcionario f){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.merge(f);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void remover(Funcionario f){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        Funcionario funcionario = gerente.find(Funcionario.class, f.getCodigo());
        gerente.remove(funcionario);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public java.util.List<Funcionario> getAll()
    {
       EntityManager gerente = GerenciadorConexao.getGerente();
       TypedQuery<Funcionario> consulta = gerente.createNamedQuery("Funcionario.todos", Funcionario.class);
       return consulta.getResultList();   
   }
    
   public List<Funcionario> getPorNome(String nome)
    {

        EntityManager gerente = GerenciadorConexao.getGerente();
        TypedQuery<Funcionario> consulta = 
                    gerente.createNamedQuery("Funcionario.porNome", Funcionario.class);
        
        consulta.setParameter("nome", "%"+nome+"%");
        return consulta.getResultList();
        
    }    
    
    public static Funcionario login(String cpf, String senha)
    {
        List<Funcionario> funcionarios = null;

        EntityManager gerente = GerenciadorConexao.getGerente();
        TypedQuery<Funcionario> consulta = 
                    gerente.createNamedQuery("Funcionario.login", Funcionario.class);
        
        consulta.setParameter("cpf", cpf);
        consulta.setParameter("senha", senha);
              
        funcionarios = consulta.getResultList();

        if(!funcionarios.isEmpty()){
            ControleFuncionario.funcionarioLogado = funcionarios.get(0);
        }

        return funcionarios.get(0);
    }
    
    public static void logout(){
        ControleFuncionario.funcionarioLogado = null;
        logado = false;
    }
    
    public static boolean isUsuarioLogado()
    {
        return funcionarioLogado != null;
    }
    
    public static void setFuncionarioLogado(Funcionario f) {
        funcionarioLogado = f;
    }

    public static Funcionario getFuncionarioLogado() {
        return funcionarioLogado;
    }
}
