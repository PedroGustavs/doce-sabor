package controle;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import modelo.Ingrediente;

public class ControleIngrediente {

    public void adicionar(Ingrediente i){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.persist(i);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void alterar(Ingrediente i){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.merge(i);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void remover(Ingrediente i){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        Ingrediente ingrediente = gerente.find(Ingrediente.class, i.getCodigo());
        gerente.remove(ingrediente);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public java.util.List<Ingrediente> getAll()
    {
       EntityManager gerente = GerenciadorConexao.getGerente();
       TypedQuery<Ingrediente> consulta = gerente.createNamedQuery("Ingrediente.todos", Ingrediente.class);
       return consulta.getResultList();   
   }
   
   public java.util.List<Ingrediente> pesquisarPorNome(String nome)
   {
       EntityManager gerente = GerenciadorConexao.getGerente();
       TypedQuery<Ingrediente> consulta = gerente.createNamedQuery("Ingrediente.porNome", Ingrediente.class);
       consulta.setParameter("nomequalquer", "%"+nome+"%");
       return consulta.getResultList();
   }
}
