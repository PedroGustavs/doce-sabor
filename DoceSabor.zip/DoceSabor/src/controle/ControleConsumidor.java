package controle;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import modelo.Consumidor;

public class ControleConsumidor {
    
    public void adicionar(Consumidor c){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.persist(c);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void alterar(Consumidor c){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        gerente.merge(c);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public void remover(Consumidor c){
        EntityManager gerente = GerenciadorConexao.getGerente();
        gerente.getTransaction().begin();
        Consumidor consumidor = gerente.find(Consumidor.class, c.getCodigo());
        gerente.remove(consumidor);
        gerente.getTransaction().commit();
        gerente.close();
    }
    
    public java.util.List<Consumidor> getAll()
    {
       EntityManager gerente = GerenciadorConexao.getGerente();
       TypedQuery<Consumidor> consulta = gerente.createNamedQuery("Consumidor.todos", Consumidor.class);
       return consulta.getResultList();   
   }
    
}
