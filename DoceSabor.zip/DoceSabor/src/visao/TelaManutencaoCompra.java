
package visao;

import controle.ControleCaixa;
import controle.ControleCompra;
import controle.ControleMovimentacao;
import controle.ControleVenda;
import java.awt.Color;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import raven.glasspanepopup.GlassPanePopup;
import javax.swing.table.DefaultTableModel;
import modelo.Caixa;
import modelo.Compra;
import modelo.Movimentacao;
import modelo.Venda;

public class TelaManutencaoCompra extends javax.swing.JDialog {

    private ControleCompra controle = new ControleCompra();
    private List<Compra> listaCompras = new ArrayList<>();
    private Date dataHoje = new Date();
    private String dataPag = "";
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private NumberFormat nfm = NumberFormat.getCurrencyInstance();
    
    public TelaManutencaoCompra(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
        listaCompras.addAll(controle.getAll());
        atualizarTabela(); 
    }
    
     public void atualizarTabela(){
        DefaultTableModel modelo = (DefaultTableModel) tabCompra.getModel();
        modelo.setRowCount(0);
        
        listaCompras.clear();
        listaCompras.addAll(controle.getAll());
        
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
        
        for (Compra c : listaCompras) {
            
            if(c.getDataPagamento() != null){      
                dataPag = sdf.format(c.getDataPagamento());
            }
            
            
            modelo.addRow(new Object[]{
                sdf.format(c.getDataCompra()),
                c.getFormaPagamento(),
                nfm.format(c.getValorFinal()),
                dataPag
            }
            );
            
            dataPag = "";
            
        }
        
    }
    
    private void init(){
        setBackground(new Color(0, 0, 0, 0));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBranco1 = new componentes.CardBranco();
        cardBranco2 = new componentes.CardBranco();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabCompra = new javax.swing.JTable();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        btnCadastrar = new componentes.ButtonGradient();
        bntAlterar = new componentes.ButtonGradient();
        btnConsultar = new componentes.ButtonGradient();
        menu2 = new componentes.Menu();
        bntPagar = new componentes.ButtonGradient();
        btnRemover = new componentes.ButtonGradient();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1250, 650));

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(129, 129, 129));
        jLabel1.setText("Manutenção das Compras");

        tabCompra.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Data da Compra", "Forma Pagamento", "Valor ", "Data Pagamento"
            }
        ));
        jScrollPane1.setViewportView(tabCompra);

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 986, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addGap(0, 993, Short.MAX_VALUE)
                .addComponent(btnSair))
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnSair)
        );

        btnCadastrar.setText("Cadastrar");
        btnCadastrar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnCadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCadastrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCadastrarMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnCadastrarMouseReleased(evt);
            }
        });
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        bntAlterar.setText("Alterar");
        bntAlterar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        bntAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntAlterarActionPerformed(evt);
            }
        });

        btnConsultar.setText("Consultar");
        btnConsultar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        bntPagar.setText("Pagar");
        bntPagar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        bntPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntPagarActionPerformed(evt);
            }
        });

        btnRemover.setText("Remover");
        btnRemover.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(187, 187, 187)
                .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(5, 5, 5))
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menu2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(cardBranco1Layout.createSequentialGroup()
                            .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bntAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(198, 198, 198)
                            .addComponent(btnRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(205, 205, 205)
                            .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(bntPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bntPagar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bntAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRemover, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(menu2, javax.swing.GroupLayout.DEFAULT_SIZE, 639, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 1257, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        TelaDadosCompra tela =  new TelaDadosCompra(null, true);
        tela.setVisible(true);
  
        if(tela.verifiqueSeClicou()){
            controle.adicionar(tela.getCompra());
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Compra Adicionada com Sucesso");
        }
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnCadastrarMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCadastrarMouseReleased
       btnCadastrar.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnCadastrarMouseReleased

    private void btnCadastrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCadastrarMouseEntered
        btnCadastrar.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnCadastrarMouseEntered

    private void btnCadastrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCadastrarMouseExited
        btnCadastrar.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnCadastrarMouseExited

    private void bntAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntAlterarActionPerformed
        int linha = tabCompra.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione uma Compra");
        }
        
        else{
            
            Compra c = new Compra();
            c = listaCompras.get(linha);
            
            if(c.getDataPagamento() != null){
                JOptionPane.showMessageDialog(this, "Não é possível alterar uma compra que já foi paga");
            }
            
            else{
            
                TelaDadosCompra tela = new TelaDadosCompra(null, true);
                tela.setCompra(listaCompras.get(linha));
                tela.mudarNome(1);
                
                if(c.getDataPagamento() != null){
                    tela.desabilitar();
                }

                tela.setVisible(true);
            
                if(tela.verifiqueSeClicou()){
                    controle.alterar(tela.getCompra());
                    JOptionPane.showMessageDialog(this, "Compra alterada com sucesso");
                    atualizarTabela();
                }
            }
        }
    }//GEN-LAST:event_bntAlterarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        int linha = tabCompra.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione uma Compra");
        }
        
        else{
            TelaDadosCompra tela = new TelaDadosCompra(null, true);
            tela.setCompra(listaCompras.get(linha));
            tela.desabilitar();
            tela.mudarNome(2);
            tela.setVisible(true);
        }
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void bntPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntPagarActionPerformed
        int linha = tabCompra.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione uma Compra");
        }
        
        else{

            if(listaCompras.get(linha).getDataPagamento() == null){
                
                boolean verificadora = false;
            
                ControleCaixa controle1 = new ControleCaixa();
            
                for(Caixa caixa: controle1.getTodos()){
                    if(caixa.getStatus().equals("Aberto")){
                        controle1.setCaixa(caixa);
                        verificadora = true;
                    }
                }
                
                if(verificadora){
               
                    if(listaCompras.get(linha).getValorFinal() > ControleCaixa.getCaixaAberto().getSaldo()){
                        JOptionPane.showMessageDialog(this, "O saldo do caixa é insuficiente");  
                    }

                    else{
                        listaCompras.get(linha).setDataPagamento(dataHoje);      
                        controle.alterar(listaCompras.get(linha));
                        atualizarTabela();
                        JOptionPane.showMessageDialog(this, "Pagamento da Compra confirmado com sucesso");

                        controle.darBaixa(listaCompras.get(linha));
                        Caixa caixaAberto = ControleCaixa.getCaixaAberto();
                        Movimentacao m = new Movimentacao();
                        m.setCaixa(ControleCaixa.getCaixaAberto());
                        m.setMotivo("Pagamento de Compra");
                        m.setTipo("Saida");
                        m.setCodigo(caixaAberto.getConjuntoMovimentacao().size()+1);
                        ControleCaixa.getCaixaAberto().adicionarMovimentacao(m);
                        m.setValor(listaCompras.get(linha).getValorFinal());
                        ControleMovimentacao movimentacao = new ControleMovimentacao();
                        movimentacao.adicionar(m);

                        ControleCaixa caixa = new ControleCaixa();

                        double saida = 0;
                        double saldo = 0;

                        saida = m.getValor();
                        saldo = caixaAberto.getSaldo() - saida;
                        caixaAberto.setSaidas(caixaAberto.getSaidas() + m.getValor());
                        caixaAberto.setSaldo(saldo);

                        caixa.alterar(caixaAberto);
                    }
                }
                else{
                   JOptionPane.showMessageDialog(this, "O caixa deve estar aberto"); 
                }
            }
            else{
                JOptionPane.showMessageDialog(this, "O Pagamento da Compra Já Ocorreu");
            }
        }
    }//GEN-LAST:event_bntPagarActionPerformed

    private void btnRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverActionPerformed
        int linha = tabCompra.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione uma Compra");
        }
        
        else{
            if(listaCompras.get(linha).getDataPagamento() == null){
                controle.remover(listaCompras.get(linha));
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Compra Excluída com sucesso");
            }
            else{
                JOptionPane.showMessageDialog(this, "Não é possível excluir uma compra já paga"); 
            }
        }
    }//GEN-LAST:event_btnRemoverActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaManutencaoCompra dialog = new TelaManutencaoCompra(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.ButtonGradient bntAlterar;
    private componentes.ButtonGradient bntPagar;
    private componentes.ButtonGradient btnCadastrar;
    private componentes.ButtonGradient btnConsultar;
    private componentes.ButtonGradient btnRemover;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private componentes.Menu menu2;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JTable tabCompra;
    // End of variables declaration//GEN-END:variables
}
