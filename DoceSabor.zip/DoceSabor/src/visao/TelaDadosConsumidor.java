package visao;

import componentes.Message;
import java.awt.Color;
import javax.swing.JOptionPane;
import modelo.Consumidor;
import modelo.Produto;
import raven.glasspanepopup.GlassPanePopup;

public class TelaDadosConsumidor extends javax.swing.JDialog {

    private int codigo;
    private boolean verificadora = false;
    private Message message;

    public TelaDadosConsumidor(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
        GlassPanePopup.install(this);
    }
    
    public void criarTela(String texto){
        message = new Message();
        GlassPanePopup.showPopup(message);    
        message.setTitulo(texto);
    }

    private void init() {
        setBackground(new Color(0, 0, 0, 0));
    }
    
    public void desabilitar(){
        txtBairro.setEnabled(false);
        txtCidade.setEnabled(false);
        txtNome.setEnabled(false);
        txtNome.setEnabled(false);
        txtFmtTelefone.setEnabled(false);
        txtFmtCep.setEnabled(false);
        txtFmtCpf.setEnabled(false);
        txtFmtNum.setEnabled(false);
        txtFmtTelefone.setEnabled(false);
        txtRua.setEnabled(false);
        jComboEstado.setEnabled(false);
    }

    public void mudarNome(int i){
        if(i == 1){
            titulo.setText("Alteração do Consumidor");
        }
        else{
            titulo.setText("Consulta do Consumidor");
        }
    }
     
    public void setConsumidor(Consumidor c) {
        this.codigo = c.getCodigo();
        txtBairro.setText(c.getBairro());
        txtCidade.setText(c.getCidade());
        txtNome.setText(c.getNome());
        txtFmtCep.setText(c.getCep());
        txtFmtTelefone.setText(c.getCpf());
        txtFmtCpf.setValue(c.getCpf());
        txtFmtNum.setValue(c.getNumero());
        txtFmtTelefone.setText(c.getTelefone());
        txtRua.setText(c.getRua());
        jComboEstado.setSelectedItem(c.getEstado());
    }

    public Consumidor getConsumidor() {

        Consumidor c = new Consumidor();

        c.setBairro(txtBairro.getText());
        c.setCep(txtFmtCep.getText());
        c.setCidade(txtCidade.getText());
        c.setCpf(txtFmtCpf.getText());
        c.setEstado(jComboEstado.getSelectedItem().toString());
        c.setNome(txtNome.getText());
        c.setNumero(((Number) txtFmtNum.getValue()).intValue());
        c.setRua(txtRua.getText());
        c.setTelefone(txtFmtTelefone.getText());
        c.setCodigo(this.codigo);
        
        return c;
    }

    public boolean verifiqueSeClicou() {
        return verificadora;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBranco1 = new componentes.CardBranco();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        cardBranco2 = new componentes.CardBranco();
        cardBranco3 = new componentes.CardBranco();
        cardBranco4 = new componentes.CardBranco();
        titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtNome = new componentes.TextField();
        txtFmtTelefone = new componentes.Jformated();
        txtFmtCpf = new componentes.Jformated();
        txtBairro = new componentes.TextField();
        txtRua = new componentes.TextField();
        txtFmtNum = new componentes.Jformated();
        txtCidade = new componentes.TextField();
        txtFmtCep = new componentes.Jformated();
        jComboEstado = new componentes.JComboBox();
        btnConfirmar = new componentes.ButtonGradient();
        menu1 = new componentes.Menu();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1250, 650));

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));
        panelBorder11.setPreferredSize(new java.awt.Dimension(54, 55));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnSair))
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnSair, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        cardBranco2.setBackground(new java.awt.Color(51, 0, 102));

        cardBranco3.setBackground(new java.awt.Color(244, 244, 244));

        cardBranco4.setBackground(Color.decode("#AE70F3"));

        titulo.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(255, 255, 255));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("Cadastro de Consumidor ");

        javax.swing.GroupLayout cardBranco4Layout = new javax.swing.GroupLayout(cardBranco4);
        cardBranco4.setLayout(cardBranco4Layout);
        cardBranco4Layout.setHorizontalGroup(
            cardBranco4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(titulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        cardBranco4Layout.setVerticalGroup(
            cardBranco4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco4Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(titulo)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel2.setText("Nome ");

        jLabel3.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel3.setText("CPF");

        jLabel5.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel5.setText("Telefone");

        jLabel6.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel6.setText("Bairro");

        jLabel7.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel7.setText("Número");

        jLabel8.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel8.setText("Cidade");

        jLabel9.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel9.setText("Estado");

        jLabel10.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel10.setText("CEP");

        jLabel11.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel11.setText("Rua");

        try {
            txtFmtTelefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtFmtCpf.setToolTipText("");
        try {
            txtFmtCpf.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtFmtNum.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));

        try {
            txtFmtCep.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####-###")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jComboEstado.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" }));

        javax.swing.GroupLayout cardBranco3Layout = new javax.swing.GroupLayout(cardBranco3);
        cardBranco3.setLayout(cardBranco3Layout);
        cardBranco3Layout.setHorizontalGroup(
            cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco3Layout.createSequentialGroup()
                        .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(txtCidade, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(txtFmtCep, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addGap(24, 24, 24))
                    .addGroup(cardBranco3Layout.createSequentialGroup()
                        .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11)
                            .addComponent(jLabel2)
                            .addComponent(txtRua, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(txtFmtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(cardBranco3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(txtFmtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(23, 23, 23))
                            .addGroup(cardBranco3Layout.createSequentialGroup()
                                .addGap(149, 149, 149)
                                .addComponent(jLabel7)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco3Layout.createSequentialGroup()
                .addGap(457, 457, 457)
                .addComponent(txtBairro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFmtNum, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );
        cardBranco3Layout.setVerticalGroup(
            cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(75, 75, 75)
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFmtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFmtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBairro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtRua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFmtNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel8)
                        .addComponent(jLabel10)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFmtCep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        btnConfirmar.setText("Confirmar");
        btnConfirmar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco2Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(cardBranco3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(cardBranco2Layout.createSequentialGroup()
                        .addGap(465, 465, 465)
                        .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(48, Short.MAX_VALUE))
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addComponent(cardBranco3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10))
        );

        menu1.setPreferredSize(new java.awt.Dimension(176, 400));

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cardBranco2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, 1057, Short.MAX_VALUE))
                .addGap(6, 6, 6))
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(menu1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(5, 5, 5))
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(17, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed

        
        if (txtNome.getText().isEmpty()) {
            criarTela("Por gentileza, preencha o nome");
            txtNome.requestFocus();
        }
        
        else if (txtNome.getText().length() > 50) {
            criarTela("O nome deve ter no máximo 50 caracteres ");
            txtNome.requestFocus();
        }
        else if(txtFmtCpf.getText().equals("   .   .   -  ")){
            criarTela("Por gentileza, preencha o CPF");
            txtFmtCpf.requestFocus();
        }

        else if(txtFmtCpf.getText().length() < 14){
           criarTela("O CPF deve ser preenchido de acordo com o formato ###.###.###-## ");
           txtFmtCpf.requestFocus(); 
        }
        
        else if (txtFmtTelefone.getText().equals("(  )     -    ")) {
            criarTela("Por gentileza, preencha o Telefone");
            txtFmtTelefone.requestFocus();
        }
        
        else if(txtFmtTelefone.getText().length() < 14){
           criarTela("O telefone deve ser preenchido de acordo com o formato (xx) xxxxx - xxxx");
           txtFmtTelefone.requestFocus(); 
        }
        
        else if (txtRua.getText().isEmpty()) {
            criarTela("Por gentileza, preencha a Rua");
            txtRua.requestFocus();
        }
        
        else if(txtRua.getText().length() > 50){
           criarTela("A rua deve ter no maximo 50 caracteres");
           txtRua.requestFocus(); 
        }
         
        else if (txtBairro.getText().isEmpty()) {
            criarTela( "Por gentileza, preencha o bairro");
            txtBairro.requestFocus();
        } 
        else if(txtBairro.getText().length() > 50){
            criarTela("O bairro deve ter no maximo 50 caracteres");
           txtBairro.requestFocus(); 
        }
        
        else if (txtFmtNum.getText().isEmpty()) {
            criarTela( "Por gentileza, preencha o número");
            txtFmtNum.requestFocus();
        } 
      
        else if (txtCidade.getText().isEmpty()) {
            criarTela("Por gentileza, preencha a cidade");
            txtCidade.requestFocus();
        } 
        
        else if(txtCidade.getText().length() > 50){
           criarTela("O cidade deve ter no maximo 50 caracteres");
           txtCidade.requestFocus(); 
        }

        
        else if (txtFmtCep.getText().equals("     -   ")) {
            criarTela("Por gentileza, preencha o CEP");
            txtFmtCep.requestFocus();
        }
        
        else if(txtFmtCep.getText().length() < 9){
           criarTela("O CEP deve ser preenchido de acordo com o formato ####-### ");
           txtFmtCep.requestFocus(); 
        }
           
        else {
            verificadora = true;
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnConfirmarActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaDadosConsumidor dialog = new TelaDadosConsumidor(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.ButtonGradient btnConfirmar;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco2;
    private componentes.CardBranco cardBranco3;
    private componentes.CardBranco cardBranco4;
    private componentes.JComboBox jComboEstado;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private componentes.Menu menu1;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JLabel titulo;
    private componentes.TextField txtBairro;
    private componentes.TextField txtCidade;
    private componentes.Jformated txtFmtCep;
    private componentes.Jformated txtFmtCpf;
    private componentes.Jformated txtFmtNum;
    private componentes.Jformated txtFmtTelefone;
    private componentes.TextField txtNome;
    private componentes.TextField txtRua;
    // End of variables declaration//GEN-END:variables
}
