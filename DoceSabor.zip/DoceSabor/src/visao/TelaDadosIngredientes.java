package visao;

import componentes.Message;
import java.awt.Color;
import javax.swing.JOptionPane;
import modelo.HistoricoConsumo;
import modelo.HistoricoProducao;
import modelo.Ingrediente;
import raven.glasspanepopup.GlassPanePopup;

public class TelaDadosIngredientes extends javax.swing.JDialog {
    
    private boolean verificadora = false;
    private int codigo;
    private Ingrediente ingrediente = null;
    private Message message;

    public TelaDadosIngredientes(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        txtFmtQntddMin.setValue(1);
        txtFmtValor.setValue(0);
        setLocationRelativeTo(null);
        GlassPanePopup.install(this); 
        init();      
    }
    
    public void criarTela(String texto){
        message = new Message();
        GlassPanePopup.showPopup(message);    
        message.setTitulo(texto);
    }
    
    private void init(){
        setBackground(new Color(0, 0, 0, 0));
    }
     
    public boolean verifiqueSeClicou(){
        return verificadora;
    }
    
    public void desabilitar(){
        txtNome.setEnabled(false);
        txtUnidade.setEnabled(false);
        txtFmtQntddMin.setEnabled(false);
        txtFmtValor.setEnabled(false);
    }
    
    public void mudarNome(int i){
        if(i == 1){
            titulo.setText("Alteração do Ingrediente");
        }
        else{
            titulo.setText("Consulta do Ingrediente");
        }
    }
     
    public Ingrediente getIngrediente(){
        
        Ingrediente ingrediente = new Ingrediente();
        
        ingrediente.setQntddMinim(((Number)txtFmtQntddMin.getValue()).intValue());
        ingrediente.setValor(((Number)txtFmtValor.getValue()).doubleValue());
        ingrediente.setUnidade(txtUnidade.getText());
        ingrediente.setCodigo(this.codigo);
        
        int qntdd = 0;
        
        if(ingrediente == null){ 
            ingrediente.setQntddEstoque(0);
            ingrediente.setStatus("Indisponível");
        }
        
        else{
            
            if(ingrediente.getConjuntoConsumo().isEmpty()){
                ingrediente.setQntddEstoque(0);
                ingrediente.setStatus("Indisponível");
            }
            
            else{
                for(HistoricoConsumo hc : this.ingrediente.getConjuntoConsumo()){
                    qntdd += hc.getQntdd();
                }

                ingrediente.setStatus("Disponível");
                ingrediente.setQntddEstoque(qntdd);
                ingrediente.setConjuntoConsumo(this.ingrediente.getConjuntoConsumo());
            }
        }
        ingrediente.setNome(txtNome.getText());
    
        

        return ingrediente;
        
    }
    
     public void setIngrediente(Ingrediente i){
       this.codigo = i.getCodigo();
       txtNome.setText(i.getNome());
       ingrediente = i;
       txtFmtValor.setValue(i.getValor());
       txtUnidade.setText(i.getUnidade());
       txtFmtQntddMin.setValue(i.getQntddMinim());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBranco1 = new componentes.CardBranco();
        menu1 = new componentes.Menu();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        cardBranco2 = new componentes.CardBranco();
        cardBranco3 = new componentes.CardBranco();
        cardBranco4 = new componentes.CardBranco();
        titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtNome = new componentes.TextField();
        txtUnidade = new componentes.TextField();
        txtFmtValor = new componentes.Jformated();
        txtFmtQntddMin = new componentes.Jformated();
        btnConfirmar = new componentes.ButtonGradient();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1250, 650));

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addContainerGap(981, Short.MAX_VALUE)
                .addComponent(btnSair)
                .addContainerGap())
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSair)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cardBranco2.setBackground(new java.awt.Color(51, 0, 102));

        cardBranco3.setBackground(new java.awt.Color(249, 249, 249));

        cardBranco4.setBackground(Color.decode("#AE70F3"));

        titulo.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(255, 255, 255));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("Cadastro de Ingrediente");

        javax.swing.GroupLayout cardBranco4Layout = new javax.swing.GroupLayout(cardBranco4);
        cardBranco4.setLayout(cardBranco4Layout);
        cardBranco4Layout.setHorizontalGroup(
            cardBranco4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(titulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco4Layout.setVerticalGroup(
            cardBranco4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco4Layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addComponent(titulo)
                .addGap(38, 38, 38))
        );

        jLabel2.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel2.setText("Nome");

        jLabel4.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel4.setText("Quantidade Minima");

        jLabel5.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel5.setText(" Valor");

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel1.setText("Unidade Medida");

        txtFmtValor.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0.00"))));

        txtFmtQntddMin.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));

        javax.swing.GroupLayout cardBranco3Layout = new javax.swing.GroupLayout(cardBranco3);
        cardBranco3.setLayout(cardBranco3Layout);
        cardBranco3Layout.setHorizontalGroup(
            cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(823, 823, 823))
                    .addGroup(cardBranco3Layout.createSequentialGroup()
                        .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco3Layout.createSequentialGroup()
                                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(cardBranco3Layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(txtUnidade, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(cardBranco3Layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(53, 53, 53))
                                    .addGroup(cardBranco3Layout.createSequentialGroup()
                                        .addComponent(txtFmtValor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGap(23, 23, 23)
                                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(txtFmtQntddMin, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap())))
        );
        cardBranco3Layout.setVerticalGroup(
            cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtUnidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFmtValor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFmtQntddMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(70, Short.MAX_VALUE))
        );

        btnConfirmar.setText("Confirmar");
        btnConfirmar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(cardBranco3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(91, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(417, 417, 417))
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addContainerGap(61, Short.MAX_VALUE)
                .addComponent(cardBranco3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, 638, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(5, 5, 5))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 1235, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 649, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed
         
        if(txtNome.getText().isEmpty()){
            criarTela("Por gentileza, preencha o nome do produto");
            txtNome.requestFocus();
        }
        
        else if(txtNome.getText().length() > 40){
            criarTela("O nome do produto deve ter no maximo 50 caracteres");
           txtNome.requestFocus(); 
        }
        
        else if(txtUnidade.getText().isEmpty()){
            criarTela("Por gentileza, preencha a unidade do produto");
            txtUnidade.requestFocus();
        }
        
        else if(txtUnidade.getText().length() > 15){
            criarTela("A unidade do produto deve ter no maximo 15 caracteres");
           txtUnidade.requestFocus(); 
        }
    
        else if(((Number)txtFmtValor.getValue()).doubleValue() <= 0){
            criarTela("Por gentileza, preencha o valor do produto");
            txtFmtValor.requestFocus();
        }
        
        else if(((Number)txtFmtQntddMin.getValue()).intValue()<= 0){
            criarTela("Por gentileza, preencha uma quantidade maior ou igual á 1");
            txtFmtQntddMin.requestFocus();
        }
        
        else{
            this.verificadora = true;
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnConfirmarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaDadosIngredientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaDadosIngredientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaDadosIngredientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaDadosIngredientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaDadosIngredientes dialog = new TelaDadosIngredientes(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.ButtonGradient btnConfirmar;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco2;
    private componentes.CardBranco cardBranco3;
    private componentes.CardBranco cardBranco4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private componentes.Menu menu1;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JLabel titulo;
    private componentes.Jformated txtFmtQntddMin;
    private componentes.Jformated txtFmtValor;
    private componentes.TextField txtNome;
    private componentes.TextField txtUnidade;
    // End of variables declaration//GEN-END:variables
}
