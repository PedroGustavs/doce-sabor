package visao;

import controle.ControleCaixa;
import controle.ControleMovimentacao;
import java.awt.Color;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Caixa;
import modelo.Compra;
import modelo.Movimentacao;

public class TelaDetalhamentoCaixa extends javax.swing.JDialog {

    private ControleCaixa controle = new ControleCaixa();
    private List<Movimentacao> listaMovimentacao = new ArrayList<>();
    private Caixa caixa;
    private double entrada = 0, saida = 0;
    private Date dataHoje = new Date();
    private String data = "";
    private double total = 0;
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    
    private NumberFormat nfm = NumberFormat.getCurrencyInstance();
    
    public TelaDetalhamentoCaixa(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
    }
    
    public void setCaixa(Caixa caixa){
        String horaAb = new SimpleDateFormat("HH:mm").format(caixa.getHorarioAbertura());
        double saldo = 0;
        
        this.caixa = caixa;
        
        atualizarTabelaEntrada();
        atualizarTabelaSaida();
        
        if(this.caixa.getStatus().equals("Aberto")){
            saldo = entrada - saida;
        }
        else{
            saldo = this.caixa.getSaldo();
        }
     
        labSaldo.setText(String.valueOf(nfm.format(saldo)));
        DiaAbertura.setText(sdf.format(caixa.getDataAbertura()));
        txtHoraAbertura.setEnabled(false);
        txtStatus.setEnabled(rootPaneCheckingEnabled);
        txtHoraAbertura.setText(horaAb);
        txtHoraAbertura.setEnabled(false);
        txtStatus.setEnabled(false);
        DiaAbertura.setEnabled(false);
        txtStatus.setText(caixa.getStatus());

        if(caixa.getStatus().equals("Fechado")){
            btnFechar.setVisible(false);
            btnMovimentar.setVisible(false);
        }
        
        if(caixa.getHorarioFechamento() != null){
            String horaFecha = new SimpleDateFormat("HH:mm").format(caixa.getHorarioFechamento());
            txtHoraFechamento.setText(horaFecha);
            txtHoraFechamento.setVisible(true);
            txtHoraFechamento.setEnabled(false);
            labHoraFecha.setVisible(true);
        }
        else{
            txtHoraFechamento.setVisible(false);
            labHoraFecha.setVisible(false);
        }

    }
    
    
    
    public void atualizarTabelaEntrada(){
        DefaultTableModel modelo = (DefaultTableModel) tabEntradas.getModel();
        modelo.setRowCount(0);
        
        listaMovimentacao.clear();
        listaMovimentacao.addAll(caixa.getConjuntoMovimentacao());
        
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
  
        for (Movimentacao m : listaMovimentacao) {
      
            if(m.getTipo().equals("Entrada")){      
                
                entrada += m.getValor();
                
                modelo.addRow(new Object[]{
                m.getMotivo(),m.getValor(),
                    
                }
                );
            }
            
        }
        
        labEntradas.setText(String.valueOf(nfm.format(entrada)));
        
    }
    
    public void atualizarTabelaSaida(){
        DefaultTableModel modelo = (DefaultTableModel) tabSaida.getModel();
        modelo.setRowCount(0);
        
        listaMovimentacao.clear();
        listaMovimentacao.addAll(caixa.getConjuntoMovimentacao());
        
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
  
        for (Movimentacao m : listaMovimentacao) {
      
            if(m.getTipo().equals("Saida")){      

                if(!m.getMotivo().equals("Fechamento do Caixa")){
                    saida += m.getValor();
                }
                
                modelo.addRow(new Object[]{
                    m.getMotivo(),
                    nfm.format(m.getValor()),   
                }
                );
            }
            
        }
        
        labSaidas.setText(String.valueOf(nfm.format(saida)));
        
    }
    
    private void init(){
        setBackground(new Color(0, 0, 0, 0));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBranco1 = new componentes.CardBranco();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        menu2 = new componentes.Menu();
        cardBranco9 = new componentes.CardBranco();
        jScrollPane8 = new javax.swing.JScrollPane();
        tabEntradas = new javax.swing.JTable();
        jLabel21 = new javax.swing.JLabel();
        cardBranco11 = new componentes.CardBranco();
        cardBranco12 = new componentes.CardBranco();
        jLabel5 = new javax.swing.JLabel();
        labEntradas = new javax.swing.JLabel();
        cardBranco10 = new componentes.CardBranco();
        jScrollPane9 = new javax.swing.JScrollPane();
        tabSaida = new javax.swing.JTable();
        jLabel22 = new javax.swing.JLabel();
        cardBranco13 = new componentes.CardBranco();
        cardBranco14 = new componentes.CardBranco();
        jLabel6 = new javax.swing.JLabel();
        labSaidas = new javax.swing.JLabel();
        btnMovimentar = new componentes.ButtonGradient();
        btnFechar = new componentes.ButtonGradient();
        jLabel2 = new javax.swing.JLabel();
        cardBranco2 = new componentes.CardBranco();
        jLabel1 = new javax.swing.JLabel();
        txtHoraAbertura = new componentes.TextField();
        labHoraFecha = new javax.swing.JLabel();
        txtHoraFechamento = new componentes.TextField();
        DiaAbertura = new componentes.TextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        cardBranco27 = new componentes.CardBranco();
        cardBranco28 = new componentes.CardBranco();
        jLabel13 = new javax.swing.JLabel();
        labSaldo = new javax.swing.JLabel();
        txtStatus = new componentes.TextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1250, 650));

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnSair))
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnSair)
        );

        cardBranco9.setPreferredSize(new java.awt.Dimension(506, 308));

        tabEntradas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Motivo", "Valor"
            }
        ));
        jScrollPane8.setViewportView(tabEntradas);

        jLabel21.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(129, 129, 129));
        jLabel21.setText("Entradas");

        cardBranco11.setBackground(new java.awt.Color(51, 0, 102));

        cardBranco12.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Valor Total ");

        labEntradas.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labEntradas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labEntradas.setText("0");

        javax.swing.GroupLayout cardBranco12Layout = new javax.swing.GroupLayout(cardBranco12);
        cardBranco12.setLayout(cardBranco12Layout);
        cardBranco12Layout.setHorizontalGroup(
            cardBranco12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
            .addComponent(labEntradas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco12Layout.setVerticalGroup(
            cardBranco12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labEntradas)
                .addContainerGap())
        );

        javax.swing.GroupLayout cardBranco11Layout = new javax.swing.GroupLayout(cardBranco11);
        cardBranco11.setLayout(cardBranco11Layout);
        cardBranco11Layout.setHorizontalGroup(
            cardBranco11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco11Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(cardBranco12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        cardBranco11Layout.setVerticalGroup(
            cardBranco11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout cardBranco9Layout = new javax.swing.GroupLayout(cardBranco9);
        cardBranco9.setLayout(cardBranco9Layout);
        cardBranco9Layout.setHorizontalGroup(
            cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco9Layout.createSequentialGroup()
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco9Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cardBranco11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE)))
                .addContainerGap())
        );
        cardBranco9Layout.setVerticalGroup(
            cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco9Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addComponent(cardBranco11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addContainerGap())
        );

        cardBranco10.setPreferredSize(new java.awt.Dimension(506, 308));

        tabSaida.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Motivo", "Valor"
            }
        ));
        jScrollPane9.setViewportView(tabSaida);

        jLabel22.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(129, 129, 129));
        jLabel22.setText("Saídas");

        cardBranco13.setBackground(new java.awt.Color(51, 0, 102));

        cardBranco14.setBackground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Valor Total ");

        labSaidas.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labSaidas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labSaidas.setText("0");

        javax.swing.GroupLayout cardBranco14Layout = new javax.swing.GroupLayout(cardBranco14);
        cardBranco14.setLayout(cardBranco14Layout);
        cardBranco14Layout.setHorizontalGroup(
            cardBranco14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
            .addComponent(labSaidas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco14Layout.setVerticalGroup(
            cardBranco14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco14Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labSaidas)
                .addContainerGap())
        );

        javax.swing.GroupLayout cardBranco13Layout = new javax.swing.GroupLayout(cardBranco13);
        cardBranco13.setLayout(cardBranco13Layout);
        cardBranco13Layout.setHorizontalGroup(
            cardBranco13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco13Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(cardBranco14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        cardBranco13Layout.setVerticalGroup(
            cardBranco13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout cardBranco10Layout = new javax.swing.GroupLayout(cardBranco10);
        cardBranco10.setLayout(cardBranco10Layout);
        cardBranco10Layout.setHorizontalGroup(
            cardBranco10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco10Layout.createSequentialGroup()
                .addGroup(cardBranco10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco10Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cardBranco13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(cardBranco10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 516, Short.MAX_VALUE)))
                .addContainerGap())
        );
        cardBranco10Layout.setVerticalGroup(
            cardBranco10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco10Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(cardBranco10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22)
                    .addComponent(cardBranco13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
                .addContainerGap())
        );

        btnMovimentar.setText("Movimentar");
        btnMovimentar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnMovimentar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMovimentarActionPerformed(evt);
            }
        });

        btnFechar.setText("Fechar");
        btnFechar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFecharActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Detalhamento do Caixa");

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(127, 127, 127));
        jLabel1.setText("Hora Abertura");

        txtHoraAbertura.setText("20h30");
        txtHoraAbertura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHoraAberturaActionPerformed(evt);
            }
        });

        labHoraFecha.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        labHoraFecha.setForeground(new java.awt.Color(127, 127, 127));
        labHoraFecha.setText("Hora Fechamento");

        txtHoraFechamento.setText("20h30");
        txtHoraFechamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHoraFechamentoActionPerformed(evt);
            }
        });

        DiaAbertura.setText("06/06/2023");
        DiaAbertura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DiaAberturaActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(128, 128, 128));
        jLabel15.setText("Dia");

        jLabel23.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(129, 129, 129));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("Dados do Caixa");

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(DiaAbertura, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtHoraAbertura, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labHoraFecha)
                    .addComponent(txtHoraFechamento, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(226, 226, 226))
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 603, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labHoraFecha)
                    .addComponent(jLabel1)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtHoraFechamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtHoraAbertura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DiaAbertura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        cardBranco27.setBackground(new java.awt.Color(51, 0, 102));

        cardBranco28.setBackground(new java.awt.Color(255, 255, 255));

        jLabel13.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("Saldo");

        labSaldo.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labSaldo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labSaldo.setText("0");

        javax.swing.GroupLayout cardBranco28Layout = new javax.swing.GroupLayout(cardBranco28);
        cardBranco28.setLayout(cardBranco28Layout);
        cardBranco28Layout.setHorizontalGroup(
            cardBranco28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
            .addComponent(labSaldo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco28Layout.setVerticalGroup(
            cardBranco28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco28Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labSaldo)
                .addContainerGap())
        );

        javax.swing.GroupLayout cardBranco27Layout = new javax.swing.GroupLayout(cardBranco27);
        cardBranco27.setLayout(cardBranco27Layout);
        cardBranco27Layout.setHorizontalGroup(
            cardBranco27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco27Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(cardBranco28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        cardBranco27Layout.setVerticalGroup(
            cardBranco27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtStatus.setText("Aberto");
        txtStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtStatusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(187, 187, 187)
                .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(5, 5, 5))
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menu2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(cardBranco1Layout.createSequentialGroup()
                                .addComponent(cardBranco27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(45, 45, 45)
                                .addComponent(txtStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(19, 19, 19))
                            .addGroup(cardBranco1Layout.createSequentialGroup()
                                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(cardBranco1Layout.createSequentialGroup()
                                        .addComponent(cardBranco9, javax.swing.GroupLayout.PREFERRED_SIZE, 496, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(39, 39, 39)
                                        .addComponent(cardBranco10, javax.swing.GroupLayout.PREFERRED_SIZE, 528, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, cardBranco1Layout.createSequentialGroup()
                                        .addGap(388, 388, 388)
                                        .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnMovimentar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(12, Short.MAX_VALUE))))
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addGap(223, 223, 223)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, 605, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txtStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel2))
                            .addComponent(cardBranco27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cardBranco9, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cardBranco10, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnMovimentar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(menu2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 1269, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 732, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        
        ControleCaixa controle = new ControleCaixa();
        Date horario = new Date();
        
        Caixa caixa = ControleCaixa.getCaixaAberto();
        
        ControleCaixa.getCaixaAberto().setStatus("Fechado");
        ControleCaixa.getCaixaAberto().setHorarioFechamento(horario);
        
        Movimentacao m = new Movimentacao();
        m.setCaixa(caixa);
        m.setCodigo(caixa.getConjuntoMovimentacao().size()+1);
        m.setMotivo("Fechamento do Caixa");
        m.setTipo("Saida");
        m.setValor(caixa.getSaldo());
        
        ControleMovimentacao movimenta = new ControleMovimentacao();
        movimenta.adicionar(m);
        
        
        caixa.adicionarMovimentacao(m);
        caixa.setSaldo(0);

        controle.fechar(caixa);

        setVisible(false);
        
    }//GEN-LAST:event_btnFecharActionPerformed

    private void txtStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtStatusActionPerformed

    private void txtHoraFechamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoraFechamentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoraFechamentoActionPerformed

    private void DiaAberturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DiaAberturaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DiaAberturaActionPerformed

    private void txtHoraAberturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoraAberturaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoraAberturaActionPerformed

    private void btnMovimentarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMovimentarActionPerformed
        TelaDadosMovimentacao tela = new TelaDadosMovimentacao(null, true);
        tela.setVisible(true);
        
        if(tela.verifiqueSeClicou()){
            ControleCaixa controle = new ControleCaixa();
            Caixa caixa = ControleCaixa.getCaixaAberto();
            ControleMovimentacao movimenta = new ControleMovimentacao();         
            Movimentacao movimentacao = tela.getMovimentacao();
  
            if(movimentacao.getTipo().equals("Entrada")){
                caixa.setEntradas(caixa.getEntradas() + movimentacao.getValor());
                caixa.setSaldo(caixa.getSaldo() + movimentacao.getValor());
            }
            
            else if(movimentacao.getTipo().equals("Saida")){
                caixa.setSaidas(caixa.getSaidas() + movimentacao.getValor());
                caixa.setSaldo(caixa.getSaldo() - movimentacao.getValor());
            }
            movimentacao.setCaixa(caixa);
            caixa.adicionarMovimentacao(movimentacao);
            movimenta.adicionar(movimentacao);
            
            this.caixa = caixa;
            
            entrada = 0;
            saida = 0;
            setCaixa(caixa);
            controle.setCaixa(caixa);
            
            atualizarTabelaEntrada();
            atualizarTabelaSaida();
            JOptionPane.showMessageDialog(null, "Movimentação adicionado com sucesso");
        }
    }//GEN-LAST:event_btnMovimentarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaDetalhamentoCaixa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaDetalhamentoCaixa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaDetalhamentoCaixa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaDetalhamentoCaixa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaDetalhamentoCaixa dialog = new TelaDetalhamentoCaixa(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.TextField DiaAbertura;
    private componentes.ButtonGradient btnFechar;
    private componentes.ButtonGradient btnMovimentar;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco10;
    private componentes.CardBranco cardBranco11;
    private componentes.CardBranco cardBranco12;
    private componentes.CardBranco cardBranco13;
    private componentes.CardBranco cardBranco14;
    private componentes.CardBranco cardBranco2;
    private componentes.CardBranco cardBranco27;
    private componentes.CardBranco cardBranco28;
    private componentes.CardBranco cardBranco9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel labEntradas;
    private javax.swing.JLabel labHoraFecha;
    private javax.swing.JLabel labSaidas;
    private javax.swing.JLabel labSaldo;
    private componentes.Menu menu2;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JTable tabEntradas;
    private javax.swing.JTable tabSaida;
    private componentes.TextField txtHoraAbertura;
    private componentes.TextField txtHoraFechamento;
    private componentes.TextField txtStatus;
    // End of variables declaration//GEN-END:variables
}
