
package visao;

import controle.ControleCaixa;
import controle.ControleFuncionario;
import controle.ControleMovimentacao;
import controle.ControleProduto;
import controle.ControleVenda;
import java.awt.Color;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Caixa;
import modelo.Movimentacao;
import modelo.Venda;

public class TelaManutencaoVenda extends javax.swing.JDialog {

    private ControleVenda controle = new ControleVenda();
    private ControleCaixa controle1 = new ControleCaixa();
    private ControleProduto controleP = new ControleProduto();
    private String dataPag = "";
    private Date dataHoje = new Date();
    private List<Venda> listaVendas = new ArrayList<>();
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private NumberFormat nfm = NumberFormat.getCurrencyInstance();
    
    public TelaManutencaoVenda(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
        
        if(ControleFuncionario.isUsuarioLogado()){
            if(ControleFuncionario.getFuncionarioLogado().getCargo().equals("Cozinheira")){
               btnConsultar.setVisible(false);
               btnPedido.setVisible(false);
               btnRemover.setVisible(false);
               btnConfirmarPag.setVisible(false);
               btnAlterar.setVisible(false);
            }
        }
 
        listaVendas.addAll(controle.getAll());
        atualizarTabela(); 
    }
    
     public void atualizarTabela(){
        DefaultTableModel modelo = (DefaultTableModel) tabVenda.getModel();
        modelo.setRowCount(0);
        
        listaVendas.clear();
        listaVendas.addAll(controle.getAll());
        
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
        
        for (Venda v : listaVendas) {
    
            if(v.getDataPagamento() != null){
                dataPag = sdf.format(v.getDataPagamento());
            }
            
            modelo.addRow(new Object[]{
                v.getTipoVenda(),
                v.getFormaPagamento(),
                nfm.format(v.getValorFinal()),
                sdf.format(v.getDataVenda()),
                dataPag
            }
                   
            );
            dataPag = "";
   
        }
        
    }
    
    private void init(){
        setBackground(new Color(0, 0, 0, 0));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBranco1 = new componentes.CardBranco();
        cardBranco2 = new componentes.CardBranco();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabVenda = new javax.swing.JTable();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        btnAlterar = new componentes.ButtonGradient();
        btnConsultar = new componentes.ButtonGradient();
        menu2 = new componentes.Menu();
        btnRemover = new componentes.ButtonGradient();
        btnPedido = new componentes.ButtonGradient();
        btnConfirmarPag = new componentes.ButtonGradient();
        btnEncomenda = new componentes.ButtonGradient();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1250, 650));

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(129, 129, 129));
        jLabel1.setText("Manutenção das Vendas");

        tabVenda.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tipo", "Forma Pagamento", "Valor", "Data Venda", "Data Pagamento"
            }
        ));
        jScrollPane1.setViewportView(tabVenda);

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 986, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnSair))
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnSair)
        );

        btnAlterar.setText("Alterar");
        btnAlterar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });

        btnConsultar.setText("Consultar");
        btnConsultar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        btnRemover.setText("Remover");
        btnRemover.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverActionPerformed(evt);
            }
        });

        btnPedido.setText("Pedido");
        btnPedido.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnPedido.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnPedidoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnPedidoMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnPedidoMouseReleased(evt);
            }
        });
        btnPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPedidoActionPerformed(evt);
            }
        });

        btnConfirmarPag.setText("Pagar");
        btnConfirmarPag.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConfirmarPag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarPagActionPerformed(evt);
            }
        });

        btnEncomenda.setText("Encomenda");
        btnEncomenda.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnEncomenda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnEncomendaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEncomendaMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnEncomendaMouseReleased(evt);
            }
        });
        btnEncomenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEncomendaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(187, 187, 187)
                .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(5, 5, 5))
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menu2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(btnConfirmarPag, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(200, 200, 200)
                        .addComponent(btnRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(195, 195, 195)
                        .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cardBranco2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(btnEncomenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnPedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnPedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEncomenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRemover, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnConfirmarPag, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(menu2, javax.swing.GroupLayout.DEFAULT_SIZE, 653, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 1257, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 664, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPedidoActionPerformed
        TelaDadosVenda tela =  new TelaDadosVenda(null, true);
        tela.alterarTipoVenda("Pedido");
        tela.setVisible(true);
  
        if(tela.verifiqueSeClicou()){
            controle.adicionar(tela.getVenda());
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Venda Adicionada com Sucesso");
        }
    }//GEN-LAST:event_btnPedidoActionPerformed

    private void btnPedidoMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPedidoMouseReleased
       btnPedido.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnPedidoMouseReleased

    private void btnPedidoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPedidoMouseEntered
        btnPedido.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnPedidoMouseEntered

    private void btnPedidoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPedidoMouseExited
        btnPedido.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnPedidoMouseExited

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        int linha = tabVenda.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione uma Venda");
        }
        
        else{
            
            Venda v = listaVendas.get(linha);
            
            if(v.getDataPagamento() != null){
                JOptionPane.showMessageDialog(this, "Não é possível alterar um pedido que já foi pago");
            }
            
            else{
            
                TelaDadosVenda tela = new TelaDadosVenda(null, true);
                
                tela.alteraOperacao("Alteração");
                tela.alterarTipoVenda(v.getTipoVenda());
                tela.setVenda(v);

                tela.setVisible(true);

                if(tela.verifiqueSeClicou()){
                    controle.alterar(tela.getVenda());
                    JOptionPane.showMessageDialog(this, "Venda alterada com sucesso");
                    atualizarTabela();
                }
            }
        }
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        int linha = tabVenda.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um consumidor");
        }
        
        else{
            TelaDadosVenda tela = new TelaDadosVenda(null, true);
            tela.alterarTipoVenda(listaVendas.get(linha).getTipoVenda());
            tela.alteraOperacao("Consulta");
            tela.setVenda(listaVendas.get(linha));
            tela.desabilitar();
            tela.setVisible(true);
        }
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnConfirmarPagActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarPagActionPerformed
        int linha = tabVenda.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione uma Venda");
        }
        
        else{
            
            Venda v = new Venda();
            v = listaVendas.get(linha);
            
            if(v.getDataPagamento() == null){
                
                boolean verificadora = false;
            
                ControleCaixa controle1 = new ControleCaixa();
            
                for(Caixa caixa: controle1.getTodos()){
                    if(caixa.getStatus().equals("Aberto")){
                        controle1.setCaixa(caixa);
                        verificadora = true;
                    }
                }
                
                if(verificadora){

                    v.setDataPagamento(dataHoje);      
                    controle.alterar(v);
                    controle.darBaixa(v);
                    atualizarTabela();
                    JOptionPane.showMessageDialog(this, "Pagamento da Venda confirmada com sucesso");

                    Caixa caixaAberto = ControleCaixa.getCaixaAberto();
                    Movimentacao m = new Movimentacao();
                    m.setCaixa(ControleCaixa.getCaixaAberto());
                    m.setMotivo("Pagamento de Venda");
                    m.setTipo("Entrada");
                    m.setCodigo(caixaAberto.getConjuntoMovimentacao().size()+1);
                    ControleCaixa.getCaixaAberto().adicionarMovimentacao(m);
                    m.setValor(v.getValorFinal());
                    ControleMovimentacao movimentacao = new ControleMovimentacao();
                    movimentacao.adicionar(m);


                    ControleCaixa caixa = new ControleCaixa();

                    double entrada = 0;
                    double saldo = 0;

                    entrada = m.getValor();
                    saldo = caixaAberto.getSaldo() + entrada;
                    caixaAberto.setEntradas(caixaAberto.getEntradas() + m.getValor());
                    caixaAberto.setSaldo(saldo);

                    caixa.alterar(caixaAberto);
                }

                else{
                    JOptionPane.showMessageDialog(this, "O caixa deve ser aberto");
                }
            }
            
            
            else{
                JOptionPane.showMessageDialog(this, "O Pagamento da Venda Já Ocorreu");
            }
        }
    }//GEN-LAST:event_btnConfirmarPagActionPerformed

    private void btnRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverActionPerformed
        int linha = tabVenda.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione uma Venda");
        }
        
        else{
            
            if(listaVendas.get(linha).getDataPagamento() == null){
                controle.remover(listaVendas.get(linha));
                atualizarTabela();
                JOptionPane.showMessageDialog(this,"Venda Excluída com sucesso");
            }
            else{
                JOptionPane.showMessageDialog(this,"A venda já foi paga");
            }
        }
    }//GEN-LAST:event_btnRemoverActionPerformed

    private void btnEncomendaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEncomendaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEncomendaMouseEntered

    private void btnEncomendaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEncomendaMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEncomendaMouseExited

    private void btnEncomendaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEncomendaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEncomendaMouseReleased

    private void btnEncomendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEncomendaActionPerformed
        TelaDadosVenda tela =  new TelaDadosVenda(null, true);
        tela.alterarTipoVenda("Encomenda");
        tela.setVisible(true);
  
        if(tela.verifiqueSeClicou()){
            controle.adicionar(tela.getVenda());
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Venda Adicionada com Sucesso");
        }
    }//GEN-LAST:event_btnEncomendaActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoVenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoVenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoVenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoVenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaManutencaoVenda dialog = new TelaManutencaoVenda(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.ButtonGradient btnAlterar;
    private componentes.ButtonGradient btnConfirmarPag;
    private componentes.ButtonGradient btnConsultar;
    private componentes.ButtonGradient btnEncomenda;
    private componentes.ButtonGradient btnPedido;
    private componentes.ButtonGradient btnRemover;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private componentes.Menu menu2;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JTable tabVenda;
    // End of variables declaration//GEN-END:variables
}
