package visao;

import controle.ControleFuncionario;

import java.awt.Color;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Fornecedor;
import modelo.Funcionario;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.swing.JRViewer;

public class TelaManutencaoFuncionario extends javax.swing.JDialog {
    
    private Date hoje = new Date();
    private SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
    private SimpleDateFormat fHora = new SimpleDateFormat("hh/mm/ss");
    NumberFormat nfm = NumberFormat.getCurrencyInstance();
    private ControleFuncionario  controle = new ControleFuncionario ();
    private List<Funcionario> listaFuncionarios = new ArrayList<>();
    
    public TelaManutencaoFuncionario(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
        listaFuncionarios.addAll(controle.getAll());
        atualizarTabela();
    }
    
     public void atualizarTabela(){
        DefaultTableModel modelo = (DefaultTableModel) tabFuncionario.getModel();
        modelo.setRowCount(0);
        
        listaFuncionarios.clear();
        listaFuncionarios.addAll(controle.getAll());
        
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }

        for (Funcionario f : listaFuncionarios) {
            modelo.addRow(new Object[]{
                f.getNome(),
                f.getCpf(),
                f.getTelefone(),
                f.getCargo(),
                nfm.format(f.getSalario()), 
            });
        }
        
    }
    
    private void init(){
        setBackground(new Color(0, 0, 0, 0));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBranco1 = new componentes.CardBranco();
        menu1 = new componentes.Menu();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        cardBranco2 = new componentes.CardBranco();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabFuncionario = new javax.swing.JTable();
        btnCad = new componentes.ButtonGradient();
        btnAlterar = new componentes.ButtonGradient();
        brnRemover = new componentes.ButtonGradient();
        btnConsultar = new componentes.ButtonGradient();
        textFieldSearch1 = new componentes.TextFieldSearch();
        jComboBox1 = new componentes.JComboBox();
        btnRelatorio = new componentes.ButtonGradient();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1250, 650));

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSair)
                .addContainerGap())
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSair)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(129, 129, 129));
        jLabel1.setText("Manutenção dos Funcionarios");

        tabFuncionario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "CPF", "Telefone", "Cargo", "Salário"
            }
        ));
        jScrollPane1.setViewportView(tabFuncionario);

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addGap(200, 743, Short.MAX_VALUE))
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE)
                .addGap(24, 24, 24))
        );

        btnCad.setText("Cadastrar");
        btnCad.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadActionPerformed(evt);
            }
        });

        btnAlterar.setText("Alterar");
        btnAlterar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });

        brnRemover.setText("Remover");
        brnRemover.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        brnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brnRemoverActionPerformed(evt);
            }
        });

        btnConsultar.setText("Consultar");
        btnConsultar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Nome", "CPF", "Telefone", "Cargo" }));

        btnRelatorio.setText("Gerar Relatório");
        btnRelatorio.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnRelatorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRelatorioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(cardBranco1Layout.createSequentialGroup()
                                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(cardBranco1Layout.createSequentialGroup()
                                        .addComponent(btnCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(208, 208, 208)
                                        .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(brnRemover, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(218, 218, 218)
                                        .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 16, Short.MAX_VALUE))
                            .addGroup(cardBranco1Layout.createSequentialGroup()
                                .addComponent(jComboBox1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(textFieldSearch1, javax.swing.GroupLayout.PREFERRED_SIZE, 721, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)))))
                .addContainerGap())
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(menu1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textFieldSearch1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(brnRemover, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 1, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 1246, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.PREFERRED_SIZE, 651, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadActionPerformed
        TelaDadosFuncionario tela =  new  TelaDadosFuncionario(null, true);
        tela.setVisible(true);
        
        if(tela.verifiqueSeClicou()){
            controle.adicionar(tela.getFuncionario());
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Funcionario Adicionado com Sucesso");
        }
    }//GEN-LAST:event_btnCadActionPerformed

    private void brnRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brnRemoverActionPerformed
        int linha = tabFuncionario.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um Funcionário");
        }
        else{
            controle.remover(listaFuncionarios.get(linha));
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Funcionário Removido com sucesso");
        }
    }//GEN-LAST:event_brnRemoverActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        int linha = tabFuncionario.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um Ingrediente");
        }
        
        else{
            TelaDadosFuncionario tela = new TelaDadosFuncionario(null, true);
            tela.setFuncionario(listaFuncionarios.get(linha));
            tela.mudarNome(1);
            tela.setVisible(true);
            
            if(tela.verifiqueSeClicou()){
                controle.alterar(tela.getFuncionario());
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Funcionário alterado com sucesso");
            }
        }
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        int linha = tabFuncionario.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um Funcionário");
        }
        
        else{
            TelaDadosFuncionario tela = new TelaDadosFuncionario(null, true);
            tela.setFuncionario(listaFuncionarios.get(linha));
            tela.desabilitar();
            tela.mudarNome(2);
            tela.setVisible(true);
        }
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRelatorioActionPerformed
        try {
    
            JasperReport relatorioCompilado
                    = JasperCompileManager.compileReport("src/relatorios/RelatorioFuncionario.jrxml");
                       
            // Preencher o relatÃ³rio com uma lista de usuÃ¡rios passada como um JRBeanCollectionDataSource
            JasperPrint relatorioPreenchido = JasperFillManager.fillReport(relatorioCompilado, null, 
                    new JRBeanCollectionDataSource(controle.getAll()));

            // Cria um dialog para colocar o relatório dentro dele
            JDialog tela = new JDialog(this, "Relatório de Funcionários", true);
            tela.setSize(800, 400);
            
            // criar um componente swing que contém o relatorio
            JRViewer painelRelatorio = new JRViewer(relatorioPreenchido);
            
            // adiciona o painel com o relatório dentro do JDialog criado
            tela.getContentPane().add(painelRelatorio);
            
            // tornar visÃ­vel a janela criada com o relatÃ³rio
            tela.setVisible(true);
            
        } catch (JRException ex) {
            Logger.getLogger(TelaManutencaoFuncionario.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "Erro ao gerar o relatório.");
        }
        
    }//GEN-LAST:event_btnRelatorioActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaManutencaoFuncionario dialog = new TelaManutencaoFuncionario(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.ButtonGradient brnRemover;
    private componentes.ButtonGradient btnAlterar;
    private componentes.ButtonGradient btnCad;
    private componentes.ButtonGradient btnConsultar;
    private componentes.ButtonGradient btnRelatorio;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco2;
    private componentes.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private componentes.Menu menu1;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JTable tabFuncionario;
    private componentes.TextFieldSearch textFieldSearch1;
    // End of variables declaration//GEN-END:variables
}
