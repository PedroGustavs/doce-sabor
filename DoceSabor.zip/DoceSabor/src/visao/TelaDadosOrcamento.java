package visao;

import componentes.Message;
import controle.ControleProduto;
import controle.ControleVenda;
import java.awt.Color;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Consumidor;
import modelo.Ingrediente;
import modelo.ItemCompra;
import modelo.ItemVenda;
import modelo.Produto;
import modelo.Venda;
import raven.glasspanepopup.GlassPanePopup;

public class TelaDadosOrcamento extends javax.swing.JDialog {
    
    private boolean verificadora = false;
    private int codigo;
    private Date dataVenda1;
    private Date dataHoje = new Date();
    private String tipoVenda = "";
    private Consumidor consumidor;
    private Message message;
    private String op = "";
    private Produto produto = null;
    private String tipo;
    private double total = 0;

    private List<ItemVenda> itens = new ArrayList<>();
    
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private NumberFormat nfm = NumberFormat.getCurrencyInstance();

    public TelaDadosOrcamento(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        dataVenda.setText(sdf.format(dataHoje));
        dataVenda1 = dataHoje;
        txtConsumidor.setEnabled(false);
        txtProduto.setEnabled(false);
        jComboFormaPagamento.setVisible(false);
        labFormaPag.setVisible(false);
        GlassPanePopup.install(this);
        dataVenda.setEnabled(false);
        labVenda.setVisible(true);
        labValidade.setVisible(true);   
        setLocationRelativeTo(null);
        txtFmtQntdd.setValue(1);
        txtProduto.setEnabled(false);
        init();      
    }
    
    public void alterarOperacao(String op){
        this.op = op;
    }
    
    public void criarTela(String texto){
        message = new Message();
        GlassPanePopup.showPopup(message);    
        message.setTitulo(texto);
    }
    
    public void alterarTipoVenda(String tipo){
        tipoVenda = tipo;
    }
    
    public void naoAprovar(){
        jComboFormaPagamento.setVisible(false);
        labFormaPag.setVisible(false);
    }
    
    public void desabilitar(){
        txtFmtQntdd.setVisible(false);
        txtProduto.setVisible(false);
        btnAddProduto.setVisible(false);
        
        if(op.equals("Consulta")){
            jComboFormaPagamento.setEnabled(false);
        }
        btnRemoverProduto.setVisible(false);
        btnProduto.setVisible(false);
        labQntdd.setVisible(false);      
        labProduto.setVisible(false);
    }
    
    public void setVenda(Venda v){
        
        labValor.setText(String.valueOf(v.getValorFinal()));
        itens = v.getConjuntoItemVenda();
        codigo = v.getCodigo();
        dataVenda.setText(sdf.format(v.getDataOrcamento()));
        labVenda.setVisible(true);
        this.codigo = v.getCodigo();
        atualizarTabelaItens();
        dataVenda1 = v.getDataOrcamento();
        consumidor = v.getConsumidor();
        alterarTipoVenda(v.getTipoVenda());

        txtConsumidor.setEnabled(false);
        txtConsumidor.setText(v.getConsumidor().getNome());
        btnConsumidor.setVisible(false);
        
        dataValidade.setVisible(true);
        labValidade.setVisible(true); 
        dataValidade.setDate(v.getDataValidade());
        dataValidade.setEnabled(false);
        
        if(op.equals("Aprovamento") || op.equals("Consulta")){
            labFormaPag.setVisible(true);
            jComboFormaPagamento.setVisible(true);          
        }           
    }
    
    public Venda getOrcamentoAprovado(){
        
        Venda venda = new Venda();
        
        venda.setValorFinal(total); 
        venda.setDataOrcamento(dataVenda1);
        venda.setTipoVenda("Pedido");
        venda.setCodigo(codigo);
        venda.setDataVenda(new Date());
        venda.setConsumidor(consumidor);
        venda.setDataValidade(dataValidade.getDate());   
        venda.setDataAprovacao(new Date());               
        venda.setFormaPagamento(jComboFormaPagamento.getSelectedItem().toString());

        for(ItemVenda iv : itens){
            venda.adicionarItemVenda(iv);
        }
         
        return venda;
    }
    
    public Venda getOrcamento(){
        
        Venda venda = new Venda();
        
        venda.setValorFinal(total); 
        venda.setDataOrcamento(dataHoje);
        venda.setTipoVenda("Orçamento");
        venda.setCodigo(codigo);
        venda.setConsumidor(consumidor);
        venda.setDataValidade(dataValidade.getDate());   
                
        for(ItemVenda iv : itens){
            venda.adicionarItemVenda(iv);
        }
         
        return venda;
    }
    
    
     private void init(){
        setBackground(new Color(0, 0, 0, 0));
    }
     
    public boolean verifiqueSeClicou(){
        return verificadora;
    }
    
    private void atualizarTabelaItens() {
        DefaultTableModel modelo = (DefaultTableModel) tabItem.getModel();

        modelo.setRowCount(0);

        total = 0; 
       
       
        for (ItemVenda iv : itens) {
            total += iv.getQntdd() * iv.getValor();
            modelo.addRow(new Object[]{
                iv.getProduto().getNome(),
                iv.getQntdd(),
                nfm.format(iv.getValor()),
                nfm.format(iv.getQntdd() * iv.getValor())
                }
            );
        }
        labValor.setText(nfm.format(total));        
    }

    public void mudarNome(int i){
        if(i == 1){
            titulo.setText("Alteração do Orçamento");
        }
        
        else if(i == 3){
            titulo.setText("Aprovamento do Orçamento");
        }
        else if(i == 2){
            titulo.setText("Consulta do Orçamento");
        }
        
        
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBranco1 = new componentes.CardBranco();
        menu1 = new componentes.Menu();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        cardBranco2 = new componentes.CardBranco();
        cardBranco3 = new componentes.CardBranco();
        cardBranco4 = new componentes.CardBranco();
        titulo = new javax.swing.JLabel();
        cardBranco9 = new componentes.CardBranco();
        jScrollPane8 = new javax.swing.JScrollPane();
        tabItem = new javax.swing.JTable();
        jLabel21 = new javax.swing.JLabel();
        labQntdd = new javax.swing.JLabel();
        labProduto = new javax.swing.JLabel();
        btnRemoverProduto = new componentes.ButtonGradient();
        btnAddProduto = new componentes.ButtonGradient();
        cardBranco11 = new componentes.CardBranco();
        cardBranco12 = new componentes.CardBranco();
        jLabel5 = new javax.swing.JLabel();
        labValor = new javax.swing.JLabel();
        txtFmtQntdd = new componentes.Jformated();
        txtProduto = new componentes.TextField();
        btnProduto = new componentes.ButtonGradient();
        cardBranco6 = new componentes.CardBranco();
        jLabel22 = new javax.swing.JLabel();
        labValidade = new javax.swing.JLabel();
        labConsumidor = new javax.swing.JLabel();
        btnConsumidor = new componentes.ButtonGradient();
        labVenda = new javax.swing.JLabel();
        dataValidade = new com.toedter.calendar.JDateChooser();
        txtConsumidor = new componentes.TextField();
        dataVenda = new componentes.TextField();
        jComboFormaPagamento = new componentes.JComboBox();
        labFormaPag = new javax.swing.JLabel();
        btnConfirmar = new componentes.ButtonGradient();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1230, 686));

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addContainerGap(977, Short.MAX_VALUE)
                .addComponent(btnSair)
                .addContainerGap())
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSair)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cardBranco2.setBackground(new java.awt.Color(51, 0, 102));
        cardBranco2.setPreferredSize(new java.awt.Dimension(964, 578));

        cardBranco3.setBackground(new java.awt.Color(249, 249, 249));
        cardBranco3.setPreferredSize(new java.awt.Dimension(919, 508));

        cardBranco4.setBackground(Color.decode("#AE70F3"));
        cardBranco4.setPreferredSize(new java.awt.Dimension(326, 73));

        titulo.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(255, 255, 255));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("Cadastro de Orçamento");

        javax.swing.GroupLayout cardBranco4Layout = new javax.swing.GroupLayout(cardBranco4);
        cardBranco4.setLayout(cardBranco4Layout);
        cardBranco4Layout.setHorizontalGroup(
            cardBranco4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(titulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco4Layout.setVerticalGroup(
            cardBranco4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(titulo)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        cardBranco9.setPreferredSize(new java.awt.Dimension(506, 308));

        tabItem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Produto", "Quantidade", "Valor Unitário", "Valor Total Item"
            }
        ));
        jScrollPane8.setViewportView(tabItem);
        if (tabItem.getColumnModel().getColumnCount() > 0) {
            tabItem.getColumnModel().getColumn(3).setHeaderValue("Valor Total Item");
        }

        jLabel21.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(129, 129, 129));
        jLabel21.setText("Itens da Venda");

        labQntdd.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labQntdd.setText("Quantidade");

        labProduto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labProduto.setText("Produto");

        btnRemoverProduto.setText("Remover");
        btnRemoverProduto.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnRemoverProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverProdutoActionPerformed(evt);
            }
        });

        btnAddProduto.setText("Cadastrar");
        btnAddProduto.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnAddProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddProdutoActionPerformed(evt);
            }
        });

        cardBranco11.setBackground(new java.awt.Color(51, 0, 102));

        cardBranco12.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Valor Total ");

        labValor.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labValor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labValor.setText("0");

        javax.swing.GroupLayout cardBranco12Layout = new javax.swing.GroupLayout(cardBranco12);
        cardBranco12.setLayout(cardBranco12Layout);
        cardBranco12Layout.setHorizontalGroup(
            cardBranco12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
            .addComponent(labValor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco12Layout.setVerticalGroup(
            cardBranco12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labValor)
                .addContainerGap())
        );

        javax.swing.GroupLayout cardBranco11Layout = new javax.swing.GroupLayout(cardBranco11);
        cardBranco11.setLayout(cardBranco11Layout);
        cardBranco11Layout.setHorizontalGroup(
            cardBranco11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco11Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(cardBranco12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        cardBranco11Layout.setVerticalGroup(
            cardBranco11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnProduto.setText("Pesquisar");
        btnProduto.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProdutoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco9Layout = new javax.swing.GroupLayout(cardBranco9);
        cardBranco9.setLayout(cardBranco9Layout);
        cardBranco9Layout.setHorizontalGroup(
            cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco9Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addComponent(jScrollPane8)
                        .addGap(6, 6, 6))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco9Layout.createSequentialGroup()
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cardBranco11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19))))
            .addGroup(cardBranco9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtFmtQntdd, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labQntdd))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addComponent(labProduto)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addComponent(txtProduto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(btnAddProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnRemoverProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))))
        );
        cardBranco9Layout.setVerticalGroup(
            cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco9Layout.createSequentialGroup()
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel21))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cardBranco11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labQntdd)
                    .addComponent(labProduto))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRemoverProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFmtQntdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cardBranco6.setPreferredSize(new java.awt.Dimension(889, 91));

        jLabel22.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(129, 129, 129));
        jLabel22.setText("Dados do Orçamento");

        labValidade.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labValidade.setText("Data Validade");

        labConsumidor.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labConsumidor.setText("Consumidor");

        btnConsumidor.setText("Pesquisar");
        btnConsumidor.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConsumidor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsumidorActionPerformed(evt);
            }
        });

        labVenda.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labVenda.setText("Data Orçamento");

        jComboFormaPagamento.setForeground(new java.awt.Color(0, 0, 0));
        jComboFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Á vista (em dinheiro)", "Cartão de Debito", "Cartão de Credito" }));

        labFormaPag.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labFormaPag.setText("Forma de Pagamento");

        javax.swing.GroupLayout cardBranco6Layout = new javax.swing.GroupLayout(cardBranco6);
        cardBranco6.setLayout(cardBranco6Layout);
        cardBranco6Layout.setHorizontalGroup(
            cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco6Layout.createSequentialGroup()
                        .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22)
                            .addGroup(cardBranco6Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(labConsumidor)))
                        .addContainerGap(779, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco6Layout.createSequentialGroup()
                        .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(cardBranco6Layout.createSequentialGroup()
                                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(cardBranco6Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(labVenda))
                                    .addComponent(dataVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(cardBranco6Layout.createSequentialGroup()
                                        .addComponent(labFormaPag)
                                        .addGap(90, 90, 90)
                                        .addComponent(labValidade))
                                    .addGroup(cardBranco6Layout.createSequentialGroup()
                                        .addComponent(jComboFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dataValidade, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(cardBranco6Layout.createSequentialGroup()
                                .addComponent(txtConsumidor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(12, 12, 12)
                                .addComponent(btnConsumidor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(11, 11, 11))))
        );
        cardBranco6Layout.setVerticalGroup(
            cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco6Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel22)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(cardBranco6Layout.createSequentialGroup()
                        .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labValidade)
                            .addComponent(labFormaPag))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataValidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(cardBranco6Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(labVenda)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dataVenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboFormaPagamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labConsumidor)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConsumidor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtConsumidor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout cardBranco3Layout = new javax.swing.GroupLayout(cardBranco3);
        cardBranco3.setLayout(cardBranco3Layout);
        cardBranco3Layout.setHorizontalGroup(
            cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cardBranco4, javax.swing.GroupLayout.DEFAULT_SIZE, 969, Short.MAX_VALUE))
                    .addGroup(cardBranco3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(cardBranco3Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(cardBranco9, javax.swing.GroupLayout.DEFAULT_SIZE, 963, Short.MAX_VALUE))
                            .addComponent(cardBranco6, javax.swing.GroupLayout.DEFAULT_SIZE, 969, Short.MAX_VALUE))))
                .addContainerGap())
        );
        cardBranco3Layout.setVerticalGroup(
            cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cardBranco6, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cardBranco9, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
                .addContainerGap())
        );

        btnConfirmar.setText("Confirmar");
        btnConfirmar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco2Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(cardBranco3, javax.swing.GroupLayout.PREFERRED_SIZE, 981, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(cardBranco2Layout.createSequentialGroup()
                        .addGap(465, 465, 465)
                        .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(cardBranco3, javax.swing.GroupLayout.DEFAULT_SIZE, 591, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.DEFAULT_SIZE, 1030, Short.MAX_VALUE)))
                .addContainerGap())
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(menu1, javax.swing.GroupLayout.DEFAULT_SIZE, 734, Short.MAX_VALUE)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.DEFAULT_SIZE, 655, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 745, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed
   
    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed
        
        if(itens.size() == 0){
            criarTela("O orçamento deve ter pelo menos 1 produto"); 
        }

        else{ 
            if(dataValidade.getDate() == null){
                criarTela("Selecione a data de validade do orçamento");
            }
            
            else{
                if(dataValidade.getDate().before(dataVenda1)){
                    criarTela("A data da validade não deve ser anterior a data em que ocorreu o orçamento."); 
                }
                
                else if(new Date().after(dataValidade.getDate())){
                    criarTela("A data de validade expirou."); 
                }
                
                else if(consumidor == null){
                    criarTela("Selecione um consumidor.");
                }

                else{
                    verificadora = true;
                    setVisible(false);
                }
            }
        }
            
    }//GEN-LAST:event_btnConfirmarActionPerformed

    private void btnAddProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddProdutoActionPerformed
         if (this.produto == null) {
             criarTela("Não foi selecionado o produto para a venda");
        }
        
        else {
            if(((Number) txtFmtQntdd.getValue()).intValue() <= 0){
                criarTela("Informe uma quantidade do produto maior ou igual a 1");
            }     
            
            else{
                boolean achou = false;
                
                for(ItemVenda iv : itens){
                    if(iv.getProduto().equals(produto)){
                        achou = true;
                        int qntddTotal = iv.getQntdd() + ((Number) txtFmtQntdd.getValue()).intValue();
                       
                        iv.setQntdd(qntddTotal);
                        txtFmtQntdd.setValue(1);
                        txtProduto.setText("");
                        this.produto = null;
                        atualizarTabelaItens();
                        criarTela("Produto adicionado com sucesso"); 
                    }
                }
                
                if(!achou){
                    ItemVenda iv = new ItemVenda();            
                    iv.setProduto(produto);
                    iv.setValor(produto.getValor());
                    iv.setQntdd(((Number) txtFmtQntdd.getValue()).intValue());
                    itens.add(iv);
                    txtFmtQntdd.setValue(1);
                    txtProduto.setText("");
                    this.produto = null;
                    atualizarTabelaItens();
                    criarTela("Produto adicionado com sucesso");
                }
            }
                            
        }
    }//GEN-LAST:event_btnAddProdutoActionPerformed

    private void btnRemoverProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverProdutoActionPerformed
        int linha = tabItem.getSelectedRow();
        
        if(linha == -1){
            criarTela("Selecione um Produto");
        }
        else{
            itens.remove(linha);
            atualizarTabelaItens();
            criarTela("Produto Excluído com sucesso");
            atualizarTabelaItens();  
        }
    }//GEN-LAST:event_btnRemoverProdutoActionPerformed

    private void btnConsumidorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsumidorActionPerformed
        TelaGetConsumidor tela = new TelaGetConsumidor(null, true);
        tela.setVisible(true);
        
        if(tela.verifiqueSeClicou()){
            consumidor = tela.getConsumidor();
            txtConsumidor.setText(consumidor.getNome());
            criarTela("Consumidor selecionado com sucesso");
        }
    }//GEN-LAST:event_btnConsumidorActionPerformed

    private void btnProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProdutoActionPerformed
        TelaGetProduto tela = new TelaGetProduto(null, true);
        tela.setVisible(true);
        
        if(tela.verifiqueSeClicou()){
            produto = tela.getProduto();
            txtProduto.setText(produto.getNome());
            criarTela("Produto selecionado com sucesso");
        }
    }//GEN-LAST:event_btnProdutoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaDadosOrcamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaDadosOrcamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaDadosOrcamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaDadosOrcamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaDadosOrcamento dialog = new TelaDadosOrcamento(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.ButtonGradient btnAddProduto;
    private componentes.ButtonGradient btnConfirmar;
    private componentes.ButtonGradient btnConsumidor;
    private componentes.ButtonGradient btnProduto;
    private componentes.ButtonGradient btnRemoverProduto;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco11;
    private componentes.CardBranco cardBranco12;
    private componentes.CardBranco cardBranco2;
    private componentes.CardBranco cardBranco3;
    private componentes.CardBranco cardBranco4;
    private componentes.CardBranco cardBranco6;
    private componentes.CardBranco cardBranco9;
    private com.toedter.calendar.JDateChooser dataValidade;
    private componentes.TextField dataVenda;
    private componentes.JComboBox jComboFormaPagamento;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JLabel labConsumidor;
    private javax.swing.JLabel labFormaPag;
    private javax.swing.JLabel labProduto;
    private javax.swing.JLabel labQntdd;
    private javax.swing.JLabel labValidade;
    private javax.swing.JLabel labValor;
    private javax.swing.JLabel labVenda;
    private componentes.Menu menu1;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JTable tabItem;
    private javax.swing.JLabel titulo;
    private componentes.TextField txtConsumidor;
    private componentes.Jformated txtFmtQntdd;
    private componentes.TextField txtProduto;
    // End of variables declaration//GEN-END:variables
}
