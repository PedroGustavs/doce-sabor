package visao;

import componentes.Message;
import controle.ControleIngrediente;
import java.awt.Color;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Compra;
import modelo.Fornecedor;
import modelo.Ingrediente;
import modelo.ItemCompra;
import raven.glasspanepopup.GlassPanePopup;



public class TelaDadosCompra extends javax.swing.JDialog {
    
    private boolean verificadora = false;
    private int codigo = -1;
    private Fornecedor fornecedor;
    private Ingrediente ingrediente = null;
    private Date dataHoje = new Date();
    private ControleIngrediente controle = new ControleIngrediente();

    private double total = 0;
    private Message message;

    List<ItemCompra> itens = new ArrayList<>();
    
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    NumberFormat nfm = NumberFormat.getCurrencyInstance();

    public TelaDadosCompra(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        GlassPanePopup.install(this);
        setLocationRelativeTo(null);
        dataCompra.setEnabled(false);
        txtFornecedor.setEnabled(false);

        dataCompra.setText(sdf.format(new Date()));
        txtFmtQntdd.setValue(1);
        txtIngrediente.setEnabled(false);
        init();      
    }
    
    public void criarTela(String texto){
        message = new Message();
        GlassPanePopup.showPopup(message);    
        message.setTitulo(texto);
    }
    
    public void desabilitar(){
        jComboFormaPagamento.setEnabled(false);
        dataCompra.setEnabled(false);
        txtFmtQntdd.setVisible(false);
        txtIngrediente.setVisible(false);
        btnAddIngrediente.setVisible(false);
        btnRemoverIngrediente.setVisible(false);
        btnIngrediente.setVisible(false);
        labQntdd.setVisible(false);
        labIngrediente.setVisible(false);
    }
    
    public void setCompra(Compra c){
        
        jComboFormaPagamento.setSelectedItem(c.getFormaPagamento());
        labValor.setText(String.valueOf(c.getValorFinal()));
        itens = c.getConjuntoItemCompra();
        dataCompra.setText(sdf.format(c.getDataCompra()));
        this.codigo = c.getCodigo();
        atualizarTabelaItens();
        txtFornecedor.setEnabled(false);
        txtFornecedor.setText(c.getFornecedor().getNome());
        btnFornecedor.setVisible(false);
        fornecedor = c.getFornecedor();
    }
    
    public Compra getCompra(){
        
        Compra compra = new Compra();
        
        compra.setValorFinal(total);
        compra.setFormaPagamento(jComboFormaPagamento.getSelectedItem().toString());
        compra.setDataCompra(dataHoje);
        compra.setFornecedor(fornecedor);

        if(codigo != -1){
            compra.setCodigo(codigo);
        }

        for(ItemCompra ic : itens){
            compra.adicionarItemCompra(ic);
        }
         
        return compra;
    }
    
    private void init(){
        setBackground(new Color(0, 0, 0, 0));
    }
     
    public boolean verifiqueSeClicou(){
        return verificadora;
    }
    
    private void atualizarTabelaItens() {
        DefaultTableModel modelo = (DefaultTableModel) tabItem.getModel();

        modelo.setRowCount(0);

        total = 0; 
       
       
        for (ItemCompra iv : itens) {
            total += iv.getQntdd() * iv.getValor();
            modelo.addRow(new Object[]{
                iv.getIngrediente().getNome(),
                iv.getQntdd(),
                nfm.format(iv.getValor()),
                    nfm.format(iv.getQntdd() * iv.getValor())
                }
            );
        }
        labValor.setText(nfm.format(total));        
    }

    public void mudarNome(int i){
        if(i == 1){
            titulo.setText("Alteração da Compra");
        }
        else{
            titulo.setText("Consulta da Compra");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBranco1 = new componentes.CardBranco();
        menu1 = new componentes.Menu();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        cardBranco2 = new componentes.CardBranco();
        cardBranco3 = new componentes.CardBranco();
        cardBranco4 = new componentes.CardBranco();
        titulo = new javax.swing.JLabel();
        cardBranco9 = new componentes.CardBranco();
        jLabel21 = new javax.swing.JLabel();
        labQntdd = new javax.swing.JLabel();
        labIngrediente = new javax.swing.JLabel();
        btnRemoverIngrediente = new componentes.ButtonGradient();
        btnAddIngrediente = new componentes.ButtonGradient();
        cardBranco11 = new componentes.CardBranco();
        cardBranco12 = new componentes.CardBranco();
        jLabel5 = new javax.swing.JLabel();
        labValor = new javax.swing.JLabel();
        txtFmtQntdd = new componentes.Jformated();
        txtIngrediente = new componentes.TextField();
        btnIngrediente = new componentes.ButtonGradient();
        jScrollPane8 = new javax.swing.JScrollPane();
        tabItem = new javax.swing.JTable();
        cardBranco6 = new componentes.CardBranco();
        jLabel22 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        labConsumidor = new javax.swing.JLabel();
        btnFornecedor = new componentes.ButtonGradient();
        labCompra = new javax.swing.JLabel();
        dataCompra = new componentes.TextField();
        txtFornecedor = new componentes.TextField();
        jComboFormaPagamento = new componentes.JComboBox();
        btnConfirmar = new componentes.ButtonGradient();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1230, 686));

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addContainerGap(977, Short.MAX_VALUE)
                .addComponent(btnSair)
                .addContainerGap())
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSair)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cardBranco2.setBackground(new java.awt.Color(51, 0, 102));
        cardBranco2.setPreferredSize(new java.awt.Dimension(964, 578));

        cardBranco3.setBackground(new java.awt.Color(249, 249, 249));
        cardBranco3.setPreferredSize(new java.awt.Dimension(919, 508));

        cardBranco4.setBackground(Color.decode("#AE70F3"));
        cardBranco4.setPreferredSize(new java.awt.Dimension(326, 73));

        titulo.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(255, 255, 255));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("Cadastro de Compra");

        javax.swing.GroupLayout cardBranco4Layout = new javax.swing.GroupLayout(cardBranco4);
        cardBranco4.setLayout(cardBranco4Layout);
        cardBranco4Layout.setHorizontalGroup(
            cardBranco4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(titulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco4Layout.setVerticalGroup(
            cardBranco4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(titulo)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        cardBranco9.setPreferredSize(new java.awt.Dimension(506, 308));

        jLabel21.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(129, 129, 129));
        jLabel21.setText("Itens da Compra");

        labQntdd.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labQntdd.setText("Quantidade");

        labIngrediente.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labIngrediente.setText("Ingrediente");

        btnRemoverIngrediente.setText("Remover");
        btnRemoverIngrediente.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        btnRemoverIngrediente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverIngredienteActionPerformed(evt);
            }
        });

        btnAddIngrediente.setText("Cadastrar");
        btnAddIngrediente.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnAddIngrediente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddIngredienteActionPerformed(evt);
            }
        });

        cardBranco11.setBackground(new java.awt.Color(51, 0, 102));

        cardBranco12.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Valor Total ");

        labValor.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labValor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labValor.setText("0");

        javax.swing.GroupLayout cardBranco12Layout = new javax.swing.GroupLayout(cardBranco12);
        cardBranco12.setLayout(cardBranco12Layout);
        cardBranco12Layout.setHorizontalGroup(
            cardBranco12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
            .addComponent(labValor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco12Layout.setVerticalGroup(
            cardBranco12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labValor)
                .addContainerGap())
        );

        javax.swing.GroupLayout cardBranco11Layout = new javax.swing.GroupLayout(cardBranco11);
        cardBranco11.setLayout(cardBranco11Layout);
        cardBranco11Layout.setHorizontalGroup(
            cardBranco11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco11Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(cardBranco12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        cardBranco11Layout.setVerticalGroup(
            cardBranco11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtFmtQntdd.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));

        btnIngrediente.setText("Pesquisar");
        btnIngrediente.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnIngrediente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngredienteActionPerformed(evt);
            }
        });

        tabItem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Ingrediente", "Quantidade", "Valor Unitário", "Valor Total Item"
            }
        ));
        jScrollPane8.setViewportView(tabItem);

        javax.swing.GroupLayout cardBranco9Layout = new javax.swing.GroupLayout(cardBranco9);
        cardBranco9.setLayout(cardBranco9Layout);
        cardBranco9Layout.setHorizontalGroup(
            cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addComponent(labQntdd)
                        .addGap(18, 18, 18)
                        .addComponent(labIngrediente)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addComponent(txtFmtQntdd, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtIngrediente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnIngrediente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addComponent(btnAddIngrediente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRemoverIngrediente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))))
            .addGroup(cardBranco9Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addComponent(jScrollPane8)
                        .addContainerGap())
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cardBranco11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19))))
        );
        cardBranco9Layout.setVerticalGroup(
            cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco9Layout.createSequentialGroup()
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cardBranco11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)))
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labQntdd)
                    .addComponent(labIngrediente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddIngrediente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRemoverIngrediente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFmtQntdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtIngrediente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnIngrediente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6))
        );

        cardBranco6.setPreferredSize(new java.awt.Dimension(889, 91));

        jLabel22.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(129, 129, 129));
        jLabel22.setText("Dados da Compra");

        jLabel4.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel4.setText("Forma de Pagamento");

        labConsumidor.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labConsumidor.setText("Fornecedor");

        btnFornecedor.setText("Pesquisar");
        btnFornecedor.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFornecedorActionPerformed(evt);
            }
        });

        labCompra.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labCompra.setText("Data da Compra");

        jComboFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Á vista (em dinheiro)", "Cartão de Debito", "Cartão de Credito" }));

        javax.swing.GroupLayout cardBranco6Layout = new javax.swing.GroupLayout(cardBranco6);
        cardBranco6.setLayout(cardBranco6Layout);
        cardBranco6Layout.setHorizontalGroup(
            cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco6Layout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(cardBranco6Layout.createSequentialGroup()
                        .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jComboFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dataCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labCompra))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(cardBranco6Layout.createSequentialGroup()
                                .addComponent(txtFornecedor, javax.swing.GroupLayout.DEFAULT_SIZE, 407, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(cardBranco6Layout.createSequentialGroup()
                                .addComponent(labConsumidor)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        cardBranco6Layout.setVerticalGroup(
            cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco6Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(labCompra)
                    .addComponent(labConsumidor))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(dataCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout cardBranco3Layout = new javax.swing.GroupLayout(cardBranco3);
        cardBranco3.setLayout(cardBranco3Layout);
        cardBranco3Layout.setHorizontalGroup(
            cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cardBranco4, javax.swing.GroupLayout.DEFAULT_SIZE, 960, Short.MAX_VALUE))
                    .addGroup(cardBranco3Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cardBranco9, javax.swing.GroupLayout.DEFAULT_SIZE, 941, Short.MAX_VALUE)
                            .addComponent(cardBranco6, javax.swing.GroupLayout.DEFAULT_SIZE, 941, Short.MAX_VALUE))
                        .addGap(0, 9, Short.MAX_VALUE)))
                .addContainerGap())
        );
        cardBranco3Layout.setVerticalGroup(
            cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cardBranco6, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cardBranco9, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        btnConfirmar.setText("Confirmar");
        btnConfirmar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(cardBranco3, javax.swing.GroupLayout.PREFERRED_SIZE, 972, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(446, 446, 446))
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(cardBranco3, javax.swing.GroupLayout.DEFAULT_SIZE, 532, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(menu1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.DEFAULT_SIZE, 602, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 692, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed
 
    
    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed
        
        if(itens.isEmpty()){
           criarTela("Por gentileza, adicione pelo menos 1 item de compra"); 
        }

        else if(fornecedor == null){
            criarTela("Por gentileza, selecione um Fornecedor");  
        }

        else{
            verificadora = true;
            setVisible(false);
        }
           
    }//GEN-LAST:event_btnConfirmarActionPerformed

    private void btnAddIngredienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddIngredienteActionPerformed
        
        if(ingrediente == null){
           JOptionPane.showMessageDialog(null,"Selecione um Ingrediente");
        }
        
        else if(((Number) txtFmtQntdd.getValue()).intValue() <= 0){
            JOptionPane.showMessageDialog(null,"Informe uma quantidade do ingrediente maior ou igual a 1");
        }  
       
        else{
            
            boolean achou = false;
                
            for(ItemCompra ic : itens){
                if(ic.getIngrediente().equals(ingrediente)){
                    achou = true;
                    int qntddTotal = ic.getQntdd() + ((Number) txtFmtQntdd.getValue()).intValue();
                    
                    ic.setQntdd(qntddTotal);
                    txtFmtQntdd.setValue(1);
                    txtIngrediente.setText("");
                    this.ingrediente = null;
                    atualizarTabelaItens(); 
                }
            }
                
            if(!achou){
                ItemCompra iv = new ItemCompra();            
                iv.setIngrediente(ingrediente);
                iv.setValor(ingrediente.getValor());
                iv.setQntdd(((Number) txtFmtQntdd.getValue()).intValue());
                itens.add(iv);
                atualizarTabelaItens();  
                JOptionPane.showMessageDialog(null,"Ingrediente Adicionado Com Sucesso");
                txtFmtQntdd.setValue(1);
                txtIngrediente.setText("");
                this.ingrediente = null;
            }
        }                          
    }//GEN-LAST:event_btnAddIngredienteActionPerformed

    private void btnRemoverIngredienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverIngredienteActionPerformed
        int linha = tabItem.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(null,"Selecione um Ingrediente");
        }
        else{
            itens.remove(linha);
            atualizarTabelaItens();
            JOptionPane.showMessageDialog(null,"Ingrediente Excluído Com Sucesso"); 
        }
    }//GEN-LAST:event_btnRemoverIngredienteActionPerformed

    private void btnFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFornecedorActionPerformed
        TelaGetFornecedor tela = new TelaGetFornecedor(null, true);
        tela.setVisible(true);
        
        if(tela.verifiqueSeClicou()){
            fornecedor = tela.getFornecedor();
            JOptionPane.showMessageDialog(null,"Fornecedor selecionado com sucesso");
            txtFornecedor.setText(fornecedor.getNome());
        }
    }//GEN-LAST:event_btnFornecedorActionPerformed

    private void btnIngredienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngredienteActionPerformed
        TelaGetIngrediente tela = new TelaGetIngrediente(null, true);
        tela.setVisible(true);
        
        if(tela.verifiqueSeClicou()){
            ingrediente = tela.getIngrediente();
            txtIngrediente.setText(ingrediente.getNome());
            JOptionPane.showMessageDialog(null,"Ingrediente selecionado com sucesso");
        }
    }//GEN-LAST:event_btnIngredienteActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaDadosCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaDadosCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaDadosCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaDadosCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaDadosCompra dialog = new TelaDadosCompra(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.ButtonGradient btnAddIngrediente;
    private componentes.ButtonGradient btnConfirmar;
    private componentes.ButtonGradient btnFornecedor;
    private componentes.ButtonGradient btnIngrediente;
    private componentes.ButtonGradient btnRemoverIngrediente;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco11;
    private componentes.CardBranco cardBranco12;
    private componentes.CardBranco cardBranco2;
    private componentes.CardBranco cardBranco3;
    private componentes.CardBranco cardBranco4;
    private componentes.CardBranco cardBranco6;
    private componentes.CardBranco cardBranco9;
    private componentes.TextField dataCompra;
    private componentes.JComboBox jComboFormaPagamento;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JLabel labCompra;
    private javax.swing.JLabel labConsumidor;
    private javax.swing.JLabel labIngrediente;
    private javax.swing.JLabel labQntdd;
    private javax.swing.JLabel labValor;
    private componentes.Menu menu1;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JTable tabItem;
    private javax.swing.JLabel titulo;
    private componentes.Jformated txtFmtQntdd;
    private componentes.TextField txtFornecedor;
    private componentes.TextField txtIngrediente;
    // End of variables declaration//GEN-END:variables
}
