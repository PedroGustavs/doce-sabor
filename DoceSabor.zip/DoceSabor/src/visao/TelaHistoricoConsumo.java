
package visao;

import componentes.Message;
import controle.ControleConsumidor;
import controle.ControleFornecedor;
import controle.ControleIngrediente;
import controle.ControleProduto;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import raven.glasspanepopup.GlassPanePopup;
import javax.swing.table.DefaultTableModel;
import modelo.Fornecedor;
import modelo.HistoricoConsumo;
import modelo.HistoricoProducao;
import modelo.Ingrediente;
import modelo.Produto;

public class TelaHistoricoConsumo extends javax.swing.JDialog {
    
    private Ingrediente ingredienteSelecionado = null; 
    private ControleIngrediente controle = new ControleIngrediente();
    private List<HistoricoConsumo> conjuntoConsumos= new ArrayList<>();
    private Message message = null;
    private SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
     
    public TelaHistoricoConsumo(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
        GlassPanePopup.install(this);
        atualizarTabela();
    }
    
    public void criarTela(String texto){
        message = new Message();
        GlassPanePopup.showPopup(message);    
        message.setTitulo(texto);
    }
    
     private void atualizarTabela()
    {
        DefaultTableModel modelo = (DefaultTableModel) tabProducao.getModel();
        
        modelo.setRowCount(0);
 
        
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }

        for(HistoricoConsumo hc : conjuntoConsumos)
        {
            modelo.addRow(new Object[]{
                hc.getQntdd(),
                formatador.format(hc.getData())
            });
        }   
    }
     
    public void setIngredienteEscolhido(Ingrediente i){
        this.ingredienteSelecionado = i;
        this.conjuntoConsumos.addAll(i.getConjuntoConsumo());
        atualizarTabela();
        titulo.setText(i.getNome());
    }
    
    private void init(){
        setBackground(new Color(0, 0, 0, 0));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBranco1 = new componentes.CardBranco();
        cardBranco2 = new componentes.CardBranco();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabProducao = new javax.swing.JTable();
        titulo = new javax.swing.JLabel();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        menu2 = new componentes.Menu();
        btnLancar = new componentes.ButtonGradient();
        btnRemover = new componentes.ButtonGradient();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1250, 650));

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(129, 129, 129));
        jLabel1.setText("Historico de Consumo");

        tabProducao.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Quantidade", "Data"
            }
        ));
        jScrollPane1.setViewportView(tabProducao);

        titulo.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        titulo.setForeground(new java.awt.Color(128, 128, 128));
        titulo.setText("jLabel2");

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 991, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(16, Short.MAX_VALUE))
                    .addGroup(cardBranco2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(titulo)
                        .addGap(52, 52, 52))))
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(titulo))
                .addGap(74, 74, 74)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addGap(0, 1004, Short.MAX_VALUE)
                .addComponent(btnSair))
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnSair)
        );

        btnLancar.setText("Lançar");
        btnLancar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnLancar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnLancarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnLancarMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnLancarMouseReleased(evt);
            }
        });
        btnLancar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLancarActionPerformed(evt);
            }
        });

        btnRemover.setText("Excluir");
        btnRemover.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(187, 187, 187)
                .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(5, 5, 5))
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menu2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(btnLancar, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnRemover, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLancar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(17, 17, 17))
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(menu2, javax.swing.GroupLayout.DEFAULT_SIZE, 639, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnLancarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLancarActionPerformed
        
        if(ingredienteSelecionado.getQntddEstoque() > 0){
            
            TelaDadosConsumo tela = new TelaDadosConsumo(null, true);
            tela.setIngrediente(ingredienteSelecionado);
            tela.setVisible(true);
            int estoqueatual=ingredienteSelecionado.getQntddEstoque();

            if(tela.verifiqueSeClicou()){

                this.ingredienteSelecionado.adicionarConsumo(tela.getConsumo());     
                ingredienteSelecionado.setQntddEstoque(ingredienteSelecionado.getQntddEstoque() - tela.getConsumo().getQntdd());

                if(ingredienteSelecionado.getQntddEstoque() == 0){
                    ingredienteSelecionado.setStatus("Indisponível");
                }

                controle.alterar(ingredienteSelecionado);
                this.conjuntoConsumos.clear();
                this.conjuntoConsumos.addAll(ingredienteSelecionado.getConjuntoConsumo());
                atualizarTabela();
                JOptionPane.showMessageDialog(null, "Histórico de Consumo adicionado com sucesso");
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "Para lançar o consumo de um ingrediente o estoque dele deve ser maior que 0");
        }

    }//GEN-LAST:event_btnLancarActionPerformed

    private void btnLancarMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLancarMouseReleased
       btnLancar.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnLancarMouseReleased

    private void btnLancarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLancarMouseEntered
        
    }//GEN-LAST:event_btnLancarMouseEntered

    private void btnLancarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLancarMouseExited
        btnLancar.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnLancarMouseExited

    private void btnRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverActionPerformed
        int linha = tabProducao.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(null, "Selecione um historico de consumo");
        }
        
        else{
            int qntddConsumida = ingredienteSelecionado.getConjuntoConsumo().get(linha).getQntdd();
            int qntddEstoque = ingredienteSelecionado.getQntddEstoque();
            
            ingredienteSelecionado.setQntddEstoque(qntddEstoque + qntddConsumida);
            
            if(ingredienteSelecionado.getQntddEstoque()== 0){
                ingredienteSelecionado.setStatus("Indisponivel");
            }
            
            else{
                ingredienteSelecionado.setStatus("Disponivel");
            }
            
            ingredienteSelecionado.removerConsumo(ingredienteSelecionado.getConjuntoConsumo().get(linha));
            
            controle.alterar(ingredienteSelecionado);
            this.conjuntoConsumos.clear();
            this.conjuntoConsumos.addAll(ingredienteSelecionado.getConjuntoConsumo());
            atualizarTabela();
            JOptionPane.showMessageDialog(null, "Historico de Consumo excluído com sucesso");
        }
        
        
    }//GEN-LAST:event_btnRemoverActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaHistoricoConsumo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaHistoricoConsumo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaHistoricoConsumo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaHistoricoConsumo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaHistoricoConsumo dialog = new TelaHistoricoConsumo(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.ButtonGradient btnLancar;
    private componentes.ButtonGradient btnRemover;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private componentes.Menu menu2;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JTable tabProducao;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
