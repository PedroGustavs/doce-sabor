
package visao;

import controle.ControleConsumidor;
import controle.ControleProduto;
import controle.ControleVenda;
import java.awt.Color;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import raven.glasspanepopup.GlassPanePopup;
import javax.swing.table.DefaultTableModel;
import modelo.Consumidor;
import modelo.ItemVenda;
import modelo.Produto;
import modelo.Venda;

public class TelaManutencaoOrcamento extends javax.swing.JDialog {

    private ControleVenda controle = new ControleVenda();
    private ControleProduto controleP = new ControleProduto();
    private String dataAprovacao = "", dataValidade = "";
    private int codigo;
    private Date dataHoje = new Date();
    private List<Venda> listaVendas = new ArrayList<>();
    private List<Venda> listaOrcamentos = new ArrayList<>();
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    NumberFormat nfm = NumberFormat.getCurrencyInstance();
    
    public TelaManutencaoOrcamento(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
        
        listaVendas.addAll(controle.getAll());
        atualizarTabela(); 
    }
    
     public void atualizarTabela(){
        DefaultTableModel modelo = (DefaultTableModel) tabVenda.getModel();
        modelo.setRowCount(0);
        
        listaVendas.clear();
        listaVendas.addAll(controle.getAll());
        
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
        
        for (Venda v : listaVendas) {
            
            if(v.getDataOrcamento()!= null){
                
                if(v.getDataAprovacao() != null){
                   dataAprovacao = sdf.format(v.getDataAprovacao()); 
                }

                sdf.format(v.getDataValidade());

                modelo.addRow(new Object[]{
                    v.getConsumidor().getNome(),
                    sdf.format(v.getDataOrcamento()),
                    sdf.format(v.getDataValidade()),
                    nfm.format(v.getValorFinal()),
                    dataAprovacao   
                } 
                );
                dataValidade = "";
                dataAprovacao = "";
            }
            
            }
        
    }
    
    private void init(){
        setBackground(new Color(0, 0, 0, 0));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToggleButton1 = new javax.swing.JToggleButton();
        cardBranco1 = new componentes.CardBranco();
        cardBranco2 = new componentes.CardBranco();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabVenda = new javax.swing.JTable();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        btnCadastrar = new componentes.ButtonGradient();
        bntAlterar = new componentes.ButtonGradient();
        btnConsultar = new componentes.ButtonGradient();
        menu2 = new componentes.Menu();
        bntRemover = new componentes.ButtonGradient();
        bntConfirmarPag = new componentes.ButtonGradient();

        jToggleButton1.setText("jToggleButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1250, 650));

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(129, 129, 129));
        jLabel1.setText("Manutenção dos Orçamentos");

        tabVenda.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Consumidor", "Data Orçamento", "Data Validade", "Valor", "Data Aprovação"
            }
        ));
        jScrollPane1.setViewportView(tabVenda);

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 986, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnSair))
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnSair)
        );

        btnCadastrar.setText("Cadastrar");
        btnCadastrar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnCadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCadastrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCadastrarMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnCadastrarMouseReleased(evt);
            }
        });
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        bntAlterar.setText("Alterar");
        bntAlterar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        bntAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntAlterarActionPerformed(evt);
            }
        });

        btnConsultar.setText("Consultar");
        btnConsultar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        bntRemover.setText("Remover");
        bntRemover.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        bntRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntRemoverActionPerformed(evt);
            }
        });

        bntConfirmarPag.setText("Aprovar");
        bntConfirmarPag.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        bntConfirmarPag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntConfirmarPagActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(187, 187, 187)
                .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(5, 5, 5))
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menu2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(cardBranco1Layout.createSequentialGroup()
                            .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bntAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(267, 267, 267)
                            .addComponent(bntRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(200, 200, 200)
                            .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(bntConfirmarPag, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bntConfirmarPag, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bntAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bntRemover, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6))
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(menu2, javax.swing.GroupLayout.DEFAULT_SIZE, 639, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 1257, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        TelaDadosOrcamento tela =  new TelaDadosOrcamento(null, true);
        tela.alterarTipoVenda("Orçamento");
        tela.alterarOperacao("Cadastramento");
        tela.setVisible(true);
  
        if(tela.verifiqueSeClicou()){
            controle.adicionar(tela.getOrcamento());
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Venda Adicionada com Sucesso");
        }
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnCadastrarMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCadastrarMouseReleased
       btnCadastrar.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnCadastrarMouseReleased

    private void btnCadastrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCadastrarMouseEntered
        btnCadastrar.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnCadastrarMouseEntered

    private void btnCadastrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCadastrarMouseExited
        btnCadastrar.setBackground(Color.decode("#CAA3EF"));
    }//GEN-LAST:event_btnCadastrarMouseExited

    private void bntAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntAlterarActionPerformed
        int linha = tabVenda.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um Orçamento");
        }
        
        else{
            
            Venda v = new Venda();
            v = listaVendas.get(linha);
            if(v.getDataAprovacao()!= null){
                JOptionPane.showMessageDialog(this, "Não é possível alterar um Orçamento que já foi aprovado");
            }
            else{
            
                TelaDadosOrcamento tela = new TelaDadosOrcamento(null, true);
               tela.setVenda(v);
                tela.mudarNome(1);
                tela.alterarOperacao("Alteracao");
                tela.alterarTipoVenda("Orçamento");
                
                tela.setVisible(true);

                if(tela.verifiqueSeClicou()){
                    controle.alterar(tela.getOrcamento());
                    atualizarTabela();
                    JOptionPane.showMessageDialog(this, "Orçamento alterado com sucesso");
                }
            }
        }
    }//GEN-LAST:event_bntAlterarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        int linha = tabVenda.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um Orçamento");
        }
        
        else{
            Venda v = new Venda();
            v = listaVendas.get(linha);
            TelaDadosOrcamento tela = new TelaDadosOrcamento(null, true);
            
            tela.alterarTipoVenda("Orçamento");
            tela.alterarOperacao("Consulta");
            tela.desabilitar();
            tela.mudarNome(2);
            tela.setVenda(v);
            tela.setVisible(true);
        }
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void bntConfirmarPagActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntConfirmarPagActionPerformed
        int linha = tabVenda.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um Orçamento");
        }
        
        else{
            Venda v = new Venda();
            v = listaVendas.get(linha);
            
            if(v.getDataAprovacao() == null){
                
                TelaDadosOrcamento tela = new TelaDadosOrcamento(null, true);
                tela.alterarOperacao("Aprovamento");
                tela.alterarTipoVenda("Orçamento");
                
                tela.desabilitar();
                tela.mudarNome(3);
                
                tela.setVenda(listaVendas.get(linha));
                tela.setVisible(true);

                if(tela.verifiqueSeClicou()){
                    controle.alterar(tela.getOrcamentoAprovado());
                    atualizarTabela();
                    JOptionPane.showMessageDialog(this, "Orçamento aprovado com sucesso");
                }
            }
            
            else{
                JOptionPane.showMessageDialog(this, "A aprovação do Orçamento Já Ocorreu");
            }
        }
    }//GEN-LAST:event_bntConfirmarPagActionPerformed

    private void bntRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntRemoverActionPerformed
        int linha = tabVenda.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um Orçamento");
        }
        
        else{
            Venda v = new Venda();
            v = listaVendas.get(linha);
            
            if(v.getDataAprovacao() == null){                 
                controle.remover(v);
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Orçamento Removido com sucesso");
            }
            
            else{
                JOptionPane.showMessageDialog(this, "Não é possível remover um Orçamento que já foi aprovado");
            }
        }
    }//GEN-LAST:event_bntRemoverActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoOrcamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoOrcamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoOrcamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaManutencaoOrcamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaManutencaoOrcamento dialog = new TelaManutencaoOrcamento(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.ButtonGradient bntAlterar;
    private componentes.ButtonGradient bntConfirmarPag;
    private componentes.ButtonGradient bntRemover;
    private componentes.ButtonGradient btnCadastrar;
    private componentes.ButtonGradient btnConsultar;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToggleButton jToggleButton1;
    private componentes.Menu menu2;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JTable tabVenda;
    // End of variables declaration//GEN-END:variables
}
