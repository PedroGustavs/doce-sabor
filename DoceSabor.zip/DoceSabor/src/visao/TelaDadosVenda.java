package visao;

import componentes.Message;
import controle.ControleProduto;
import controle.ControleVenda;
import java.awt.Color;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Consumidor;
import modelo.Ingrediente;
import modelo.ItemCompra;
import modelo.ItemVenda;
import modelo.Produto;
import modelo.Venda;
import raven.glasspanepopup.GlassPanePopup;

public class TelaDadosVenda extends javax.swing.JDialog {
    
    private boolean verificadora = false;
    private int codigo;
    private Date dataVenda1;
    private Date dataHoje = new Date();
    private String tipoVenda = "";
    private Consumidor consumidor;
    private Produto produto = null;
    private Message message;
    private String operacao = "Cadastro";
    private double total = 0;

    List<ItemVenda> itens = new ArrayList<>();
    
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    NumberFormat nfm = NumberFormat.getCurrencyInstance();

    public TelaDadosVenda(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        inicializarTela();
        verificaTipoVenda();
        setLocationRelativeTo(null);
        GlassPanePopup.install(this);
    }
    
    public void inicializarTela(){
        setBackground(new Color(0, 0, 0, 0));
        dataVenda.setText(sdf.format(dataHoje));
        dataVenda.setEnabled(false);
        txtFmtQntdd.setValue(1);
        txtProduto.setEnabled(false);
        labConclusao.setVisible(false);
        labEntrega.setVisible(false);
        dataEntrega.setVisible(false);
        dataConclusao.setVisible(false);
    }
    
    public void verificaTipoVenda(){

        if(tipoVenda.equals("Encomenda")){
            txtConsumidor.setVisible(true);
            btnConsumidor.setVisible(true);
            labConsumidor.setVisible(true);
            title1.setText(""+operacao+" de Encomenda");
            jLabel22.setText("Dados da Encomenda");
            labVenda.setText("Data da Encomenda");
        }
        else{
            title1.setText(""+operacao+" do Pedido");
            jLabel22.setText("Dados do Pedido");
            labVenda.setText("Data do Pedido");
            btnConsumidor.setVisible(false);
            txtConsumidor.setVisible(false);
            labConsumidor.setVisible(false);
        }
    }
    
    public void alteraOperacao(String operacao){
        this.operacao = operacao;
    }
    
    public void criarTela(String texto){
        message = new Message();
        GlassPanePopup.showPopup(message);    
        message.setTitulo(texto);
    }
    
    public void alterarTipoVenda(String tipo){
        tipoVenda = tipo;
        verificaTipoVenda();
    }
    
    public void desabilitar(){
        txtFmtQntdd.setVisible(false);
        txtProduto.setVisible(false);
        dataConclusao.setEnabled(false);
        dataEntrega.setEnabled(false);
        btnAddProduto.setVisible(false);
        btnRemoverProduto.setVisible(false);
        btnProduto.setVisible(false);
        labQntdd.setVisible(false);
        labProduto.setVisible(false);
    }
    
    public void mudarTitulo(){
        switch (operacao) {
            case "Alterar":
                title1.setText("Alteração de "+tipoVenda+"");

            break;
                
            case "Consulta":
                title1.setText("Consulta de "+tipoVenda+"");
                break;
           
        }
    }
    
    public void setVenda(Venda v){
        mudarTitulo();
        
        labValor.setText(String.valueOf(v.getValorFinal()));
        itens = v.getConjuntoItemVenda();
        dataVenda1 = v.getDataVenda();
        dataVenda.setText(sdf.format(v.getDataVenda()));
        labVenda.setVisible(true);
        this.codigo = v.getCodigo();
        jComboFormaPagamento.setSelectedItem(v.getFormaPagamento());
        atualizarTabelaItens();

        if(v.getTipoVenda().equals("Encomenda")){
            txtConsumidor.setEnabled(false);
            txtConsumidor.setText(v.getConsumidor().getNome());
            btnConsumidor.setVisible(false);
            consumidor = v.getConsumidor();
            labConclusao.setVisible(true);
            labEntrega.setVisible(true);   
            dataConclusao.setVisible(true);
            dataEntrega.setVisible(true);
            jComboFormaPagamento.setEnabled(false);
            
            if(v.getDataConclusao() != null){
                dataConclusao.setDate(v.getDataConclusao());   
            }
            
            if(v.getDataEntrega() != null){
                dataEntrega.setDate(v.getDataEntrega());
            }
        }
        
        else{
            labConclusao.setVisible(false);
            labEntrega.setVisible(false);   
            dataConclusao.setVisible(false);
            dataEntrega.setVisible(false);
        }
    }
    public Venda getVenda(){
        
        Venda venda = new Venda();

        venda.setValorFinal(total); 
        venda.setFormaPagamento(jComboFormaPagamento.getSelectedItem().toString());
        venda.setDataVenda(dataHoje);
        venda.setTipoVenda(tipoVenda);
        venda.setCodigo(codigo);
        
        for(ItemVenda iv : itens){
            venda.adicionarItemVenda(iv);
        }

        if(dataEntrega.getDate() != null){
            venda.setDataEntrega(dataEntrega.getDate());               
        }

        if(dataConclusao.getDate() != null){
            venda.setDataConclusao(dataConclusao.getDate());   
        } 

        if(consumidor != null){
            venda.setConsumidor(consumidor);
        }
         
        return venda;
    }
  
    public boolean verifiqueSeClicou(){
        return verificadora;
    }
    
    private void atualizarTabelaItens() {
        DefaultTableModel modelo = (DefaultTableModel) tabItem.getModel();

        modelo.setRowCount(0);

        total = 0; 
       
       
        for (ItemVenda iv : itens) {
            total += iv.getQntdd() * iv.getValor();
            modelo.addRow(new Object[]{
                iv.getProduto().getNome(),
                iv.getQntdd(),
                nfm.format(iv.getValor()),
                nfm.format(iv.getQntdd() * iv.getValor())
                }
            );
        }
        labValor.setText(nfm.format(total));        
    }

    public void mudarNome(int i){
        if(i == 1){
            title1.setText("Alteração da Venda");
        }
        else{
            title1.setText("Consulta da Venda");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBranco1 = new componentes.CardBranco();
        menu1 = new componentes.Menu();
        panelBorder11 = new componentes.PanelBorder1();
        btnSair = new javax.swing.JButton();
        cardBranco2 = new componentes.CardBranco();
        cardBranco3 = new componentes.CardBranco();
        cardBranco4 = new componentes.CardBranco();
        title1 = new javax.swing.JLabel();
        cardBranco9 = new componentes.CardBranco();
        jScrollPane8 = new javax.swing.JScrollPane();
        tabItem = new javax.swing.JTable();
        jLabel21 = new javax.swing.JLabel();
        labQntdd = new javax.swing.JLabel();
        btnRemoverProduto = new componentes.ButtonGradient();
        btnAddProduto = new componentes.ButtonGradient();
        cardBranco11 = new componentes.CardBranco();
        cardBranco12 = new componentes.CardBranco();
        jLabel5 = new javax.swing.JLabel();
        labValor = new javax.swing.JLabel();
        txtFmtQntdd = new componentes.Jformated();
        txtProduto = new componentes.TextField();
        labProduto = new javax.swing.JLabel();
        btnProduto = new componentes.ButtonGradient();
        cardBranco6 = new componentes.CardBranco();
        jLabel22 = new javax.swing.JLabel();
        labConclusao = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        labEntrega = new javax.swing.JLabel();
        labConsumidor = new javax.swing.JLabel();
        btnConsumidor = new componentes.ButtonGradient();
        labVenda = new javax.swing.JLabel();
        dataEntrega = new com.toedter.calendar.JDateChooser();
        dataConclusao = new com.toedter.calendar.JDateChooser();
        jComboFormaPagamento = new componentes.JComboBox();
        dataVenda = new componentes.TextField();
        txtConsumidor = new componentes.TextField();
        btnConfirmar = new componentes.ButtonGradient();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        cardBranco1.setBackground(new java.awt.Color(255, 255, 255));
        cardBranco1.setPreferredSize(new java.awt.Dimension(1230, 686));

        panelBorder11.setBackground(new java.awt.Color(153, 51, 255));

        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cross-mark-button-48.png"))); // NOI18N
        btnSair.setBorderPainted(false);
        btnSair.setContentAreaFilled(false);
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBorder11Layout = new javax.swing.GroupLayout(panelBorder11);
        panelBorder11.setLayout(panelBorder11Layout);
        panelBorder11Layout.setHorizontalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder11Layout.createSequentialGroup()
                .addContainerGap(977, Short.MAX_VALUE)
                .addComponent(btnSair)
                .addContainerGap())
        );
        panelBorder11Layout.setVerticalGroup(
            panelBorder11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSair)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cardBranco2.setBackground(new java.awt.Color(51, 0, 102));
        cardBranco2.setPreferredSize(new java.awt.Dimension(964, 578));

        cardBranco3.setBackground(new java.awt.Color(249, 249, 249));
        cardBranco3.setPreferredSize(new java.awt.Dimension(919, 508));

        cardBranco4.setBackground(Color.decode("#AE70F3"));
        cardBranco4.setPreferredSize(new java.awt.Dimension(326, 73));

        title1.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        title1.setForeground(new java.awt.Color(255, 255, 255));
        title1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        title1.setText("Cadastro de Pedido");

        javax.swing.GroupLayout cardBranco4Layout = new javax.swing.GroupLayout(cardBranco4);
        cardBranco4.setLayout(cardBranco4Layout);
        cardBranco4Layout.setHorizontalGroup(
            cardBranco4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco4Layout.setVerticalGroup(
            cardBranco4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(title1)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        cardBranco9.setPreferredSize(new java.awt.Dimension(506, 308));

        tabItem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Produto", "Quantidade", "Valor Unitário", "Valor Total Item"
            }
        ));
        jScrollPane8.setViewportView(tabItem);
        if (tabItem.getColumnModel().getColumnCount() > 0) {
            tabItem.getColumnModel().getColumn(3).setHeaderValue("Valor Total Item");
        }

        jLabel21.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(129, 129, 129));
        jLabel21.setText("Itens da Venda");

        labQntdd.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labQntdd.setText("Quantidade");

        btnRemoverProduto.setText("Remover");
        btnRemoverProduto.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnRemoverProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverProdutoActionPerformed(evt);
            }
        });

        btnAddProduto.setText("Cadastrar");
        btnAddProduto.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnAddProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddProdutoActionPerformed(evt);
            }
        });

        cardBranco11.setBackground(new java.awt.Color(51, 0, 102));

        cardBranco12.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Valor Total ");

        labValor.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labValor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labValor.setText("0");

        javax.swing.GroupLayout cardBranco12Layout = new javax.swing.GroupLayout(cardBranco12);
        cardBranco12.setLayout(cardBranco12Layout);
        cardBranco12Layout.setHorizontalGroup(
            cardBranco12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
            .addComponent(labValor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco12Layout.setVerticalGroup(
            cardBranco12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labValor)
                .addContainerGap())
        );

        javax.swing.GroupLayout cardBranco11Layout = new javax.swing.GroupLayout(cardBranco11);
        cardBranco11.setLayout(cardBranco11Layout);
        cardBranco11Layout.setHorizontalGroup(
            cardBranco11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco11Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(cardBranco12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        cardBranco11Layout.setVerticalGroup(
            cardBranco11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        labProduto.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labProduto.setText("Produto");

        btnProduto.setText("Pesquisar");
        btnProduto.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProdutoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco9Layout = new javax.swing.GroupLayout(cardBranco9);
        cardBranco9.setLayout(cardBranco9Layout);
        cardBranco9Layout.setHorizontalGroup(
            cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtFmtQntdd, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labQntdd))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(cardBranco9Layout.createSequentialGroup()
                                .addComponent(txtProduto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(36, 36, 36)
                                .addComponent(btnAddProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnRemoverProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(8, 8, 8))
                            .addGroup(cardBranco9Layout.createSequentialGroup()
                                .addComponent(labProduto)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 928, Short.MAX_VALUE)
                            .addGroup(cardBranco9Layout.createSequentialGroup()
                                .addComponent(jLabel21)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cardBranco11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(19, 19, 19))))
        );
        cardBranco9Layout.setVerticalGroup(
            cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco9Layout.createSequentialGroup()
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco9Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel21)
                        .addGap(38, 38, 38))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cardBranco11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labQntdd)
                    .addComponent(labProduto))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFmtQntdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAddProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRemoverProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(7, Short.MAX_VALUE))
        );

        cardBranco6.setPreferredSize(new java.awt.Dimension(889, 91));

        jLabel22.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(129, 129, 129));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("Dados do Pedido");

        labConclusao.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labConclusao.setText("Data Conclusão");

        jLabel4.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabel4.setText("Forma de Pagamento");

        labEntrega.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labEntrega.setText("Data Entrega");

        labConsumidor.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labConsumidor.setText("Consumidor");

        btnConsumidor.setText("Pesquisar");
        btnConsumidor.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConsumidor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsumidorActionPerformed(evt);
            }
        });

        labVenda.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        labVenda.setText("Data Pedido");

        dataEntrega.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dataEntregaMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dataEntregaMousePressed(evt);
            }
        });

        jComboFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Á vista (em dinheiro)", "Cartão de Debito", "Cartão de Credito" }));

        javax.swing.GroupLayout cardBranco6Layout = new javax.swing.GroupLayout(cardBranco6);
        cardBranco6.setLayout(cardBranco6Layout);
        cardBranco6Layout.setHorizontalGroup(
            cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco6Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jComboFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labVenda)
                    .addComponent(dataVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labConsumidor)
                    .addGroup(cardBranco6Layout.createSequentialGroup()
                        .addComponent(txtConsumidor, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnConsumidor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dataEntrega, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labEntrega))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labConclusao)
                    .addComponent(dataConclusao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11))
            .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cardBranco6Layout.setVerticalGroup(
            cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel22)
                .addGap(20, 20, 20)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(labVenda)
                    .addComponent(labConsumidor)
                    .addComponent(labEntrega)
                    .addComponent(labConclusao))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dataEntrega, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(cardBranco6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jComboFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(dataVenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtConsumidor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnConsumidor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(dataConclusao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout cardBranco3Layout = new javax.swing.GroupLayout(cardBranco3);
        cardBranco3.setLayout(cardBranco3Layout);
        cardBranco3Layout.setHorizontalGroup(
            cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cardBranco4, javax.swing.GroupLayout.DEFAULT_SIZE, 969, Short.MAX_VALUE))
                    .addGroup(cardBranco3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cardBranco6, javax.swing.GroupLayout.DEFAULT_SIZE, 963, Short.MAX_VALUE)
                            .addComponent(cardBranco9, javax.swing.GroupLayout.DEFAULT_SIZE, 963, Short.MAX_VALUE))))
                .addContainerGap())
        );
        cardBranco3Layout.setVerticalGroup(
            cardBranco3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cardBranco4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(cardBranco6, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cardBranco9, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        btnConfirmar.setText("Confirmar");
        btnConfirmar.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cardBranco2Layout = new javax.swing.GroupLayout(cardBranco2);
        cardBranco2.setLayout(cardBranco2Layout);
        cardBranco2Layout.setHorizontalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(cardBranco3, javax.swing.GroupLayout.PREFERRED_SIZE, 981, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cardBranco2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(458, 458, 458))
        );
        cardBranco2Layout.setVerticalGroup(
            cardBranco2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco2Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addComponent(cardBranco3, javax.swing.GroupLayout.PREFERRED_SIZE, 580, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout cardBranco1Layout = new javax.swing.GroupLayout(cardBranco1);
        cardBranco1.setLayout(cardBranco1Layout);
        cardBranco1Layout.setHorizontalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(panelBorder11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.DEFAULT_SIZE, 1030, Short.MAX_VALUE)))
                .addContainerGap())
        );
        cardBranco1Layout.setVerticalGroup(
            cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardBranco1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(cardBranco1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(menu1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(cardBranco1Layout.createSequentialGroup()
                        .addComponent(panelBorder11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cardBranco2, javax.swing.GroupLayout.DEFAULT_SIZE, 664, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cardBranco1, javax.swing.GroupLayout.DEFAULT_SIZE, 754, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed
   
    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed
        
        if(itens.size() == 0){
            criarTela("A venda deve ter pelo menos 1 produto"); 
        }

        else if(jComboFormaPagamento.getSelectedItem().toString().equals("Encomenda") && consumidor == null){
            criarTela("Selecione um Consumidor");  
        }
            
        else if(operacao.equals("Alteração")){
        
            
            if(tipoVenda.equals("Encomenda")){
                 
                if(dataConclusao.getDate() != null && dataConclusao.getDate().before(dataVenda1)){
                    criarTela("A data da finalização da encomenda deve ser posterior ou igual a data em que ocorreu a venda."); 
                }

                else if(dataEntrega.getDate() != null && dataEntrega.getDate().before(dataVenda1)){
                    criarTela("A data da entrega da encomenda deve ser posteriar ou igual a data em que ocorreu a venda."); 
                }

                else if(dataEntrega.getDate() != null && dataConclusao.getDate() == null){
                    criarTela("Para selecionar a data de entrega a data de conclusão não deve ser nula");
                }
                
                else if(dataEntrega.getDate() != null && dataEntrega.getDate().before(dataConclusao.getDate())){
                    criarTela("A data de entrega não deve ser anterior a data de conclusão");
                }
            }
            
            
            verificadora = true;
            setVisible(false);
        }
            
        else{
            verificadora = true;
            setVisible(false);
        }
                        
    }//GEN-LAST:event_btnConfirmarActionPerformed

    private void btnAddProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddProdutoActionPerformed
         if (this.produto == null) {
            JOptionPane.showMessageDialog(null, "Não foi selecionado o produto para a venda");
        }
        
        else {
            if(((Number) txtFmtQntdd.getValue()).intValue() <= 0){
                JOptionPane.showMessageDialog(null, "Informe uma quantidade do produto maior ou igual a 1");
            } 
            else if(((Number) txtFmtQntdd.getValue()).intValue() > produto.getEstoque()){
                JOptionPane.showMessageDialog(null, "O estoque do produto é insuficiente ");
            }
            
            else{
                boolean achou = false;
                
                for(ItemVenda iv : itens){
                    if(iv.getProduto().equals(produto)){
                        achou = true;
                        int qntddTotal = iv.getQntdd() + ((Number) txtFmtQntdd.getValue()).intValue();
                        
                        if(qntddTotal > produto.getEstoque()){
                            JOptionPane.showMessageDialog(null, "O estoque do produto é insuficiente"); 
                        }
                        else{
                            iv.setQntdd(qntddTotal);
                            txtFmtQntdd.setValue(1);
                            txtProduto.setText("");
                            this.produto = null;
                            atualizarTabelaItens();
                        }
                    }
                }
                
                if(!achou){
                    ItemVenda iv = new ItemVenda();            
                    iv.setProduto(produto);
                    iv.setValor(produto.getValor());
                    iv.setQntdd(((Number) txtFmtQntdd.getValue()).intValue());
                    itens.add(iv);
                    txtFmtQntdd.setValue(1);
                    txtProduto.setText("");
                    this.produto = null;
                    atualizarTabelaItens();
                    JOptionPane.showMessageDialog(null, "Produto adicionado com sucesso");
                }
            }
        }            
    }//GEN-LAST:event_btnAddProdutoActionPerformed

    private void btnRemoverProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverProdutoActionPerformed
        int linha = tabItem.getSelectedRow();
        
        if(linha == -1){
            JOptionPane.showMessageDialog(null, "Selecione um Produto");
        }
        else{
            itens.remove(linha);
            atualizarTabelaItens();
            JOptionPane.showMessageDialog(null, "Produto Excluído com sucesso");
            atualizarTabelaItens();  
        }
    }//GEN-LAST:event_btnRemoverProdutoActionPerformed

    private void btnConsumidorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsumidorActionPerformed
        TelaGetConsumidor tela = new TelaGetConsumidor(null, true);
        tela.setVisible(true);
        
        if(tela.verifiqueSeClicou()){
            consumidor = tela.getConsumidor();
            txtConsumidor.setText(consumidor.getNome());
            JOptionPane.showMessageDialog(null, "Consumidor selecionado com sucesso");
        }
    }//GEN-LAST:event_btnConsumidorActionPerformed

    private void dataEntregaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataEntregaMousePressed
        dataEntrega.setDateFormatString(sdf.format(dataEntrega.getDate()));
    }//GEN-LAST:event_dataEntregaMousePressed

    private void dataEntregaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataEntregaMouseClicked
        dataEntrega.setDateFormatString(sdf.format(dataEntrega.getDate()));
    }//GEN-LAST:event_dataEntregaMouseClicked

    private void btnProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProdutoActionPerformed
        TelaGetProduto tela = new TelaGetProduto(null, true);
        tela.setVisible(true);

        if(tela.verifiqueSeClicou()){
            produto = tela.getProduto();
            txtProduto.setText(produto.getNome());
            JOptionPane.showMessageDialog(null, "Produto selecionado com sucesso");
        }
    }//GEN-LAST:event_btnProdutoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaDadosVenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaDadosVenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaDadosVenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaDadosVenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaDadosVenda dialog = new TelaDadosVenda(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private componentes.ButtonGradient btnAddProduto;
    private componentes.ButtonGradient btnConfirmar;
    private componentes.ButtonGradient btnConsumidor;
    private componentes.ButtonGradient btnProduto;
    private componentes.ButtonGradient btnRemoverProduto;
    private javax.swing.JButton btnSair;
    private componentes.CardBranco cardBranco1;
    private componentes.CardBranco cardBranco11;
    private componentes.CardBranco cardBranco12;
    private componentes.CardBranco cardBranco2;
    private componentes.CardBranco cardBranco3;
    private componentes.CardBranco cardBranco4;
    private componentes.CardBranco cardBranco6;
    private componentes.CardBranco cardBranco9;
    private com.toedter.calendar.JDateChooser dataConclusao;
    private com.toedter.calendar.JDateChooser dataEntrega;
    private componentes.TextField dataVenda;
    private componentes.JComboBox jComboFormaPagamento;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JLabel labConclusao;
    private javax.swing.JLabel labConsumidor;
    private javax.swing.JLabel labEntrega;
    private javax.swing.JLabel labProduto;
    private javax.swing.JLabel labQntdd;
    private javax.swing.JLabel labValor;
    private javax.swing.JLabel labVenda;
    private componentes.Menu menu1;
    private componentes.PanelBorder1 panelBorder11;
    private javax.swing.JTable tabItem;
    private javax.swing.JLabel title1;
    private componentes.TextField txtConsumidor;
    private componentes.Jformated txtFmtQntdd;
    private componentes.TextField txtProduto;
    // End of variables declaration//GEN-END:variables
}
