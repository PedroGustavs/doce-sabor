CREATE DATABASE doce_sabor;
USE doce_sabor;

CREATE TABLE produto(
   codigo_produto INTEGER AUTO_INCREMENT NOT NULL PRIMARY  KEY,
   nome VARCHAR(40) NOT NULL,
   qntdd_estoque INTEGER NOT NULL,
   qntdd_min INTEGER NOT NULL,
   valor_unitario DOUBLE NOT NULL,
   status VARCHAR(15) NOT NULL
);
INSERT INTO produto(codigo_produto, nome, qntdd_estoque,
qntdd_min, valor_unitario, status)
VALUES
(1, "Bolo de Morango", 0, 2, 45.00, "Indisponível"),
(2, "Bolo de Laranja", 0, 2, 50.00, "Indisponível"),
(3, "Bolo de Chocolate", 0, 2, 56.0, "Indisponível"),
(4, "Bolo de Nutella com Ninha", 0, 2, 45.00, "Indisponível"),
(5, "Coxinha de Frango", 0, 2, 4.50, "Indisponível"),
(6, "Coxinha de Carne", 0, 2, 5.50, "Indisponível"),
(7, "Torta de Limão", 0, 2, 24.50, "Indisponível"),
(8, "Torta de chocolate", 0, 2, 4.50, "Indisponível"),
(9, "Empadão com Catupiry", 0, 2, 34.50, "Indisponível"),
(10, "Esfira de Carne", 0, 2, 6.50, "Indisponível"),
(11, "Esfira de de Frango", 0, 2, 4.50, "Indisponível"),
(12, "Pedaço de Pudim", 0, 2, 4.50, "Indisponível");


CREATE TABLE ingrediente(
    codigo_ingrediente INTEGER AUTO_INCREMENT NOT NULL PRIMARY KEY,
    nome VARCHAR(40) NOT NULL,
    qntdd_min INTEGER NOT NULL,
    qntdd_estoque INTEGER NOT NULL,
    valor_unitario DOUBLE NOT NULL,
    status VARCHAR(15) NOT NULL,
    unidade_medida VARCHAR (15) NOT NULL
);
INSERT INTO ingrediente(codigo_ingrediente, nome, qntdd_estoque,
qntdd_min, valor_unitario, status, unidade_medida)
VALUES
(1, "Farinha de Trigo", 0, 2, 6.00, "Indisponível", "1kg"),
(2, "Leite Condensado", 0, 2, 7.00, "Indisponível", "350g"),
(3, "Chocolate em Pó", 0, 2, 9.00, "Indisponível", "1kg"),
(4, "Leite Ninho", 0, 2, 15.00, "Indisponível", "1kg"),
(5, "Pacote de Catupiry", 0, 2, 10.0, "Indisponível", "1.2kg"),
(6, "Pacote de Cheddar", 0, 2, 10.0, "Indisponível", "1.2kg"),
(7, "Creme de Leite", 0, 2, 4.50, "Indisponível", "350g"),
(8, "Pacote de Morango", 0, 2, 10.00, "Indisponível", "500g"),
(9, "Pacote de Batata", 0, 2, 24.50, "Indisponível", "2kg"),
(10, "Leite", 0, 2, 8.50, "Indisponível", "1 litro");


CREATE TABLE consumidor(
    codigo_consumidor INTEGER AUTO_INCREMENT NOT NULL PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    rua VARCHAR(50) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    numero INTEGER NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep VARCHAR(9) NOT NULL
);
INSERT INTO consumidor(codigo_consumidor, nome, cpf,
telefone, rua, bairro, numero, cidade, estado, cep)
VALUES
(1, "Jaqueline dos Santos", "345.678.980-30", "(18)99416-9476", "Teresina", "Vila Palmira", 345, 
"Presidente Epitácio", "SP", "19470-000"),
(2, "Reinaldo Rodrigues Alves", "256.456.128-56", "(18)99416-9476", "Teresina", "Vila Palmira", 345, 
"Presidente Epitácio", "SP", "19470-000"),
(3, "João Kleber", "345.678.980-30", "(18)99416-9476", "Teresina", "Vila Palmira", 345, 
"Presidente Epitácio", "SP", "19470-000"),
(4, "Isabelly Kauane", "345.678.980-30", "(18)99416-9476", "Teresina", "Vila Palmira", 345, 
"Presidente Epitácio", "SP", "19470-000");


CREATE TABLE fornecedor(
    codigo_fornecedor INT NOT NULL PRIMARY KEY AUTO_INCREMENT ,
    nome VARCHAR(50) NOT NULL,
    nomeContato VARCHAR(50) NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    email VARCHAR(50) NOT NULL,
    cnpj VARCHAR(18) NOT NULL,
    rua VARCHAR(50) NOT NULL,
    numero INTEGER NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep VARCHAR(9) NOT NULL
);

INSERT INTO fornecedor(codigo_fornecedor, nome, nomeContato,
telefone, email, cnpj, rua, numero, bairro, cidade, estado, cep)
VALUES
(1, "Matheus Serralvo", "Matheus", "(18)99416-9476", "mateus.serralvo@gmail.com",
"04.010.446/0001-58", "Teresina", 345, "Vila Palmira", 
"Presidente Epitácio", "SP", "19470-000"),
(2, "Elena", "Ordinária", "(18)99416-9476", "elena123@gmail.com",
"04.010.446/0004-58", "Teresina", 345, "Vila Palmira", 
"Presidente Epitácio", "SP", "19470-000");

CREATE TABLE funcionario(
    codigo_funcionario INT NOT NULL PRIMARY KEY AUTO_INCREMENT ,
    cpf VARCHAR(14) NOT NULL,
    data_admissao DATE NOT NULL,
    senha VARCHAR(15) NOT NULL,
    nome VARCHAR(50) NOT NULL,
    salario DOUBLE NOT NULL,
    email VARCHAR(50) NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    cargo VARCHAR(15) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    rua VARCHAR(50) NOT NULL,
    numero INTEGER NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    dataDemissao DATE
);

INSERT INTO funcionario(codigo_funcionario, cpf, data_admissao, senha, nome, salario, email,
telefone, cargo, bairro, rua, numero, cidade, estado, cep)
VALUE
(1, "479.840.598-10", '2018-10-20', "catradora5", "Pedro Gustavo Rodrigues dos Santos", 5.900, 
"pedro.gustavo@aluno.ifsp.edu.br", "(18)99683-5208", "Administrador", "Vila Palmira", "Teresina", 345, "Presidente Epitácio",
"SP", "19470-000"),
(2, "111.111.111-11", '2019-10-20', "111", "Evellyn", 1.900, 
"evellyn@aluno.ifsp.edu.br", "(18)99683-5208", "Atendente", "Vila Palmira", "Teresina", 345, "Presidente Epitácio",
"SP", "19470-000"),
(3, "222.222.222-22", '2020-10-22', "22", "Diana Cristina de Medeiros", 1.600, 
"diana@aluno.ifsp.edu.br", "(18)99683-5208", "Cozinheira", "Vila Palmira", "Teresina", 345, "Presidente Epitácio",
"SP", "19470-000");

CREATE TABLE historico_consumo(
    codigo_ingrediente INT NOT NULL,
    codigo_consumo INT NOT NULL,
    qntdd INT NOT NULL,
    data DATE NOT NULL,
    PRIMARY KEY(codigo_ingrediente, codigo_consumo),
    FOREIGN KEY (codigo_ingrediente) REFERENCES ingrediente(codigo_ingrediente)
);

CREATE TABLE historico_producao(
    codigo_produto INT NOT NULL,
    codigo_producao INT NOT NULL,
    qntdd INT NOT NULL,
    data DATE NOT NULL,
    PRIMARY KEY(codigo_produto, codigo_producao),
    FOREIGN KEY (codigo_produto) REFERENCES produto(codigo_produto)
);

CREATE TABLE venda(
    codigo_venda INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    codigo_caixa INT,
    codigo_consumidor INT,
    dataVenda DATE,
    dataConclusao DATE,
    dataOrcamento DATE,
    dataPagamento DATE,
    dataEntrega DATE, 
    tipoVenda VARCHAR(45) NOT NULL,
    dataAprovacao DATE,
    dataValidade DATE,
    valorFinal DOUBLE NOT NULL,
    formaPagamento VARCHAR(30),
    FOREIGN KEY (codigo_consumidor)
    REFERENCES consumidor (codigo_consumidor)
);

CREATE TABLE compra(
	codigo_compra INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    codigo_caixa INT,
    codigo_fornecedor INT NOT NULL,
    dataCompra DATE NOT NULL,
    dataPagamento DATE,
    valorFinal DOUBLE NOT NULL,
    formaPagamento VARCHAR(30) NOT NULL,
    FOREIGN KEY (codigo_fornecedor)
    REFERENCES fornecedor (codigo_fornecedor)
);

CREATE TABLE item_venda (
  codigo_venda INT NOT NULL,
  codigo_produto INT NOT NULL,
  codigo_item INT NOT NULL,
  qntdd INT NOT NULL,
  valor DOUBLE NOT NULL,
  PRIMARY KEY (codigo_venda, codigo_item),
  FOREIGN KEY (codigo_venda)
       REFERENCES venda (codigo_venda),
  FOREIGN KEY (codigo_produto)
       REFERENCES produto (codigo_produto)
);

CREATE TABLE item_compra (
  codigo_compra INT NOT NULL,
  codigo_ingrediente INT NOT NULL,
  codigo_item INT NOT NULL,
  qntdd INT NOT NULL,
  valor DOUBLE NOT NULL,
  PRIMARY KEY (codigo_compra, codigo_item),
  FOREIGN KEY (codigo_compra)
       REFERENCES compra (codigo_compra),
  FOREIGN KEY (codigo_ingrediente)
       REFERENCES ingrediente (codigo_ingrediente)
);

CREATE TABLE caixa ( 
  codigo_funcionario INT NOT NULL,
  codigo_caixa INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  status VARCHAR(45) NOT NULL,
  entradas DOUBLE,
  data_abertura DATE NOT NULL,
  horario_abertura TIME NOT NULL,
  horario_fechamento TIME,
  saidas DOUBLE,
  saldo DOUBLE,
  FOREIGN KEY (codigo_funcionario)
       REFERENCES funcionario (codigo_funcionario)
);

CREATE TABLE movimentacao (
	codigo_caixa INT NOT NULL,
	codigo_movimentacao INT NOT NULL,
    PRIMARY KEY (codigo_caixa, codigo_movimentacao),
    valor DOUBLE NOT NULL, 
    motivo VARCHAR(200) NOT NULL,
    tipo VARCHAR(15) NOT NULL,
    FOREIGN KEY (codigo_caixa)
       REFERENCES caixa(codigo_caixa)
);